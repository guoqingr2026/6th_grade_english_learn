# Release 发布包说明

本目录为**可直接分发**的运行包，仅包含网页运行所需文件。

## 目录结构

```
release/
├── index.html
├── app.js
├── styles.css
├── 启动.bat
├── 使用说明.txt
├── .nojekyll                 # GitHub Pages 部署用
├── FINAL_PRODUCT_MANUAL.md
└── assets/
    └── images/
        ├── unit1-travel.svg
        ├── unit2-festival.svg
        ├── unit3-health.svg
        ├── unit4-money.svg
        ├── unit5-space.svg
        └── unit6-energy.svg
```

## 维护者：同步最新代码

在项目根目录双击运行：

```
sync-release.bat
```

会将根目录的最新 `index.html / app.js / styles.css / assets` 同步到本目录。

## 打包 ZIP

压缩整个 `release` 文件夹即可分发。
