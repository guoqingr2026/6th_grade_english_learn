const unitMeta = {
  1: "Unit 1 Amazing landmarks",
  2: "Unit 2 Getting together",
  3: "Unit 3 Healthy life",
  4: "Unit 4 Managing money well",
  5: "Unit 5 Exploring space",
  6: "Unit 6 Energy, nature and us",
};

const unitLocalImage = {
  1: "./assets/images/unit1-travel.svg",
  2: "./assets/images/unit2-festival.svg",
  3: "./assets/images/unit3-health.svg",
  4: "./assets/images/unit4-money.svg",
  5: "./assets/images/unit5-space.svg",
  6: "./assets/images/unit6-energy.svg",
};

const POINT_REWARD = 50;
const POINT_PENALTY = 20;

// Data source: appendix catalog in textbook_catalog.py (PEP Grade 6 Book 1, 2024 edition).
const appendixUnits = [
  {
    num: 1,
    partAVocab: [["was", "/wɒz/", "v.", "是（am/is 的过去式）"], ["climb", "/klaɪm/", "v.", "攀登；爬"], ["go", "/ɡəʊ/", "v.", "去"], ["see", "/siː/", "v.", "看见"], ["eat", "/iːt/", "v.", "吃"], ["take", "/teɪk/", "v.", "拍摄；拿"], ["send", "/send/", "v.", "邮寄；发送"], ["kilometre", "/ˈkɪləmiːtə(r)/", "n.", "千米"], ["thousand", "/ˈθaʊznd/", "num.", "一千"], ["view", "/vjuː/", "n.", "景色；风景"], ["amazing", "/əˈmeɪzɪŋ/", "adj.", "极好的；令人惊奇的"], ["Great Wall", "/ɡreɪt wɔːl/", "n.", "长城"], ["Gingerbread House", "/ˈdʒɪndʒəbred haʊs/", "n.", "姜饼屋"], ["Eiffel Tower", "/ˈaɪfl ˈtaʊə(r)/", "n.", "埃菲尔铁塔"]],
    partBVocab: [["village", "/ˈvɪlɪdʒ/", "n.", "村庄"], ["dry", "/draɪ/", "adj.", "干的"], ["clay", "/kleɪ/", "n.", "黏土；陶土"], ["inspiring", "/ɪnˈspaɪərɪŋ/", "adj.", "鼓舞人心的"], ["bamboo", "/ˌbæmˈbuː/", "n.", "竹子"], ["pumpkin", "/ˈpʌmpkɪn/", "n.", "南瓜"], ["restaurant", "/ˈrestrɒnt/", "n.", "餐馆"], ["airport", "/ˈeəpɔːt/", "n.", "机场"], ["Terracotta Warriors", "/ˌterəˈkɒtə ˈwɒriəz/", "n.", "兵马俑"]],
    partAPhrases: [["climb the Great Wall", "爬长城"], ["last weekend", "上周末"], ["over the summer holidays", "暑假期间"], ["take many photos", "拍很多照片"], ["a must-see attraction", "必游景点"], ["visit the Gingerbread House", "参观姜饼屋"], ["send me some pictures", "给我发一些照片"], ["walk around the Palace Museum", "逛故宫博物院"]],
    partBPhrases: [["go to Xi'an", "去西安"], ["eat Xi'an noodles", "吃西安面条"], ["see the Terracotta Warriors", "看兵马俑"], ["ride bikes on the old city wall", "在古城墙上骑自行车"], ["the bamboo forest", "竹林"], ["pumpkin soup", "南瓜汤"], ["red rice", "红米饭"], ["by high-speed train", "乘高铁"], ["by cable car", "乘缆车"]],
    partASentences: [["How was your weekend / holiday?", "你周末/假期过得怎么样？"], ["It was great / fun / amazing!", "非常棒！"], ["What did you do last Saturday?", "你上周六做了什么？"], ["I visited the Gingerbread House.", "我参观了姜饼屋。"], ["Please send me some pictures.", "请发给我一些照片。"]],
    partBSentences: [["Where did you go over the summer holidays?", "你暑假去哪儿了？"], ["I went to Xi'an with my family.", "我和家人去了西安。"], ["What did you do there?", "你们在那儿做了什么？"], ["We went to see the Terracotta Warriors.", "我们去看了兵马俑。"], ["Did you climb the Great Wall?", "你爬长城了吗？"], ["Yes, I did. / No, I didn't.", "是的/不，没有。"]],
  },
  {
    num: 2,
    partAVocab: [["dress", "/dres/", "v.", "穿衣服"], ["paste", "/peɪst/", "v.", "粘贴"], ["gala", "/ˈɡɑːlə/", "n.", "演出；庆典"], ["count down", "/kaʊnt daʊn/", "phr.", "倒计时"], ["marathon", "/ˈmærəθən/", "n.", "马拉松"], ["cheer", "/tʃɪə(r)/", "v.", "欢呼；加油"], ["book fair", "/bʊk feə(r)/", "n.", "书市"], ["yesterday", "/ˈjestədeɪ/", "adv.", "昨天"], ["exciting", "/ɪkˈsaɪtɪŋ/", "adj.", "令人激动的"]],
    partBVocab: [["race", "/reɪs/", "n.", "赛跑"], ["run", "/rʌn/", "v.", "跑"], ["winner", "/ˈwɪnə(r)/", "n.", "获胜者"], ["wake", "/weɪk/", "v.", "醒；醒来"], ["begin", "/bɪˈɡɪn/", "v.", "开始"], ["win", "/wɪn/", "v.", "获胜"], ["share", "/ʃeə(r)/", "v.", "分享"], ["make zongzi", "/meɪk ˈzɒŋzi/", "phr.", "包粽子"]],
    partAPhrases: [["paste fu on the door", "在门上贴福字"], ["dress in red", "穿红色衣服"], ["wait for the Spring Festival Gala", "等待春节联欢晚会"], ["count down to the new year", "倒计时迎接新年"], ["clean the house", "打扫房子"], ["have a big dinner", "吃一顿大餐"]],
    partBPhrases: [["go to a marathon", "参加马拉松"], ["work as a volunteer", "志愿者工作"], ["cheer for the runners", "为跑步者加油"], ["join an online book fair", "参加线上书市"], ["share ideas", "分享想法"], ["the dragon boat race", "龙舟赛"], ["wake up early", "早起"], ["make zongzi", "包粽子"]],
    partASentences: [["Did you eat mooncakes?", "你们吃月饼了吗？"], ["Yes, we did. / No, we didn't.", "是的/不，没有。"], ["What did you do for the Spring Festival?", "你春节做了什么？"]],
    partBSentences: [["Did you take a trip?", "你们去旅行了吗？"], ["What did you like about it?", "你喜欢哪一点？"], ["My dad and I cleaned the house.", "我和爸爸打扫了房子。"], ["Finally, his team won the race!", "最后，他的队伍赢得了比赛！"]],
  },
  {
    num: 3,
    partAVocab: [["cold", "/kəʊld/", "n.", "感冒"], ["ill", "/ɪl/", "adj.", "不舒服"], ["head", "/hed/", "n.", "头"], ["runny nose", "/ˈrʌni nəʊz/", "n.", "流鼻涕"], ["fever", "/ˈfiːvə(r)/", "n.", "发烧"], ["cough", "/kɒf/", "n./v.", "咳嗽"], ["soon", "/suːn/", "adv.", "很快"], ["hospital", "/ˈhɒspɪtl/", "n.", "医院"], ["better", "/ˈbetə(r)/", "adj.", "好转的"]],
    partBVocab: [["diet", "/ˈdaɪət/", "n.", "日常饮食"], ["stay up", "/steɪ ʌp/", "phr.", "熬夜"], ["unhappy", "/ʌnˈhæpi/", "adj.", "不快乐的"], ["video", "/ˈvɪdiəʊ/", "n.", "视频"], ["should", "/ʃʊd/", "modal v.", "应该"], ["exercise", "/ˈeksəsaɪz/", "n./v.", "锻炼"], ["healthy", "/ˈhelθi/", "adj.", "健康的"], ["club", "/klʌb/", "n.", "俱乐部"]],
    partAPhrases: [["have a bad cold", "得了重感冒"], ["have a fever", "发烧"], ["have a cough", "咳嗽"], ["see a doctor", "看医生"], ["go to hospital", "去医院"], ["get well soon", "早日康复"]],
    partBPhrases: [["have a healthy diet", "保持健康饮食"], ["exercise often", "经常锻炼"], ["think about happy things", "想开心的事情"], ["join clubs and teams", "加入俱乐部和团队"], ["make video calls", "打视频电话"], ["cheer you up", "让你振作起来"]],
    partASentences: [["How do you feel?", "你感觉怎么样？"], ["I feel ill. My head hurts and I have a runny nose.", "我感觉不舒服。"], ["Maybe you should see a doctor.", "也许你应该看医生。"], ["You shouldn't stay up late.", "你不应该熬夜。"]],
    partBSentences: [["How can we live a healthy life?", "我们怎样过健康生活？"], ["We should exercise too.", "我们也应该锻炼。"], ["What are you going to do?", "你打算做什么？"], ["I'm going to see a doctor.", "我打算看医生。"]],
  },
  {
    num: 4,
    partAVocab: [["money", "/ˈmʌni/", "n.", "钱"], ["pocket money", "/ˈpɒkɪt ˈmʌni/", "n.", "零花钱"], ["schoolbag", "/ˈskuːlbæɡ/", "n.", "书包"], ["goods", "/ɡʊdz/", "n.", "商品"], ["service", "/ˈsɜːvɪs/", "n.", "服务"], ["drink", "/drɪŋk/", "n.", "饮料"], ["buy", "/baɪ/", "v.", "买"], ["spend", "/spend/", "v.", "花费"]],
    partBVocab: [["save", "/seɪv/", "v.", "储蓄"], ["save up", "/seɪv ʌp/", "phr.", "攒钱"], ["sale", "/seɪl/", "n.", "打折出售"], ["ticket", "/ˈtɪkɪt/", "n.", "票"], ["manage", "/ˈmænɪdʒ/", "v.", "管理"], ["need", "/niːd/", "v.", "需要"], ["want", "/wɒnt/", "v.", "想要"], ["plan", "/plæn/", "n./v.", "计划"], ["half", "/hɑːf/", "n.", "一半"]],
    partAPhrases: [["pocket money", "零花钱"], ["buy goods", "购买商品"], ["pay for services", "支付服务费用"], ["a cold drink", "一杯冷饮"], ["spend pocket money", "花零花钱"]],
    partBPhrases: [["save up for a computer", "攒钱买电脑"], ["write a spending plan", "写花钱计划"], ["wait for a sale", "等打折"], ["be careful with money", "谨慎用钱"], ["buy a nice gift", "买一份礼物"], ["use money wisely", "明智用钱"]],
    partASentences: [["How are you going to spend your pocket money?", "你打算怎么花零花钱？"], ["I am going to buy a schoolbag.", "我打算买书包。"], ["We use money to buy goods.", "我们用钱买商品。"]],
    partBSentences: [["I need to save more.", "我需要多存钱。"], ["Should I also buy some ice cream?", "我也该买冰淇淋吗？"], ["Maybe you can wait for a sale.", "也许你可以等打折。"]],
  },
  {
    num: 5,
    partAVocab: [["space", "/speɪs/", "n.", "太空"], ["planet", "/ˈplænɪt/", "n.", "行星"], ["star", "/stɑː(r)/", "n.", "星星"], ["moon", "/muːn/", "n.", "月亮"], ["Earth", "/ɜːθ/", "n.", "地球"], ["sky", "/skaɪ/", "n.", "天空"], ["telescope", "/ˈtelɪskəʊp/", "n.", "望远镜"], ["spaceship", "/ˈspeɪsʃɪp/", "n.", "宇宙飞船"]],
    partBVocab: [["Mars", "/mɑːz/", "n.", "火星"], ["astronaut", "/ˈæstrənɔːt/", "n.", "宇航员"], ["space station", "/speɪs ˈsteɪʃn/", "n.", "空间站"], ["outer space", "/ˈaʊtə speɪs/", "n.", "外太空"], ["rover", "/ˈrəʊvə(r)/", "n.", "探测器"], ["soil", "/sɔɪl/", "n.", "土壤"], ["solar system", "/ˈsəʊlə ˈsɪstəm/", "n.", "太阳系"], ["rocket", "/ˈrɒkɪt/", "n.", "火箭"]],
    partAPhrases: [["look into space", "观察太空"], ["in the solar system", "在太阳系中"], ["use a telescope", "使用望远镜"], ["travel in outer space", "在外太空旅行"], ["in the science museum", "在科学博物馆"]],
    partBPhrases: [["explore space", "探索太空"], ["live on a space station", "住在空间站"], ["the red planet", "红色星球"], ["send a rover to Mars", "向火星发送探测器"], ["go into space by spaceship", "乘宇宙飞船进入太空"], ["make us proud", "让我们自豪"]],
    partASentences: [["How can we explore space?", "我们怎样探索太空？"], ["We can use telescopes.", "我们可以使用望远镜。"], ["There are eight planets in our solar system.", "太阳系有八颗行星。"]],
    partBSentences: [["Where do astronauts live in space?", "宇航员住在哪？"], ["On a space station.", "在空间站。"], ["China sent a rover to Mars last year.", "中国去年向火星发送了探测器。"]],
  },
  {
    num: 6,
    partAVocab: [["energy", "/ˈenədʒi/", "n.", "能源"], ["electricity", "/ɪˌlekˈtrɪsəti/", "n.", "电"], ["solar power", "/ˈsəʊlə ˈpaʊə(r)/", "n.", "太阳能"], ["wind power", "/wɪnd ˈpaʊə(r)/", "n.", "风能"], ["water power", "/ˈwɔːtə ˈpaʊə(r)/", "n.", "水能"], ["green energy", "/ɡriːn ˈenədʒi/", "n.", "绿色能源"], ["power station", "/ˈpaʊə ˈsteɪʃn/", "n.", "发电站"], ["come from", "/kʌm frɒm/", "phr.", "来自"]],
    partBVocab: [["reduce", "/rɪˈdjuːs/", "v.", "减少"], ["reuse", "/ˌriːˈjuːz/", "v.", "重复使用"], ["recycle", "/ˌriːˈsaɪkl/", "v.", "回收利用"], ["unplug", "/ʌnˈplʌɡ/", "v.", "拔掉插头"], ["air conditioner", "/eə kənˈdɪʃənə(r)/", "n.", "空调"], ["shower", "/ˈʃaʊə(r)/", "n./v.", "淋浴"], ["LED lighting", "/ˌel iː ˈdiː/", "n.", "LED 照明"], ["save energy", "/seɪv ˈenədʒi/", "phr.", "节约能源"]],
    partAPhrases: [["come from rivers and lakes", "来自江河湖泊"], ["make electricity", "发电"], ["green energy", "绿色能源"], ["turn off lights", "关灯"], ["save energy", "节约能源"]],
    partBPhrases: [["take quick showers", "快速淋浴"], ["the 3R rules", "3R 原则"], ["protect the Earth", "保护地球"], ["unplug the computer", "拔掉电脑插头"], ["use LED lighting", "使用 LED 照明"], ["reduce, reuse and recycle", "减少、重复使用、回收"]],
    partASentences: [["Where does water come from?", "水来自哪里？"], ["It comes from rivers and lakes.", "它来自江河湖泊。"], ["Where does electricity come from?", "电来自哪里？"], ["It comes from power stations.", "它来自发电站。"]],
    partBSentences: [["We should save energy and use green energy.", "我们应该节约能源并使用绿色能源。"], ["We should reduce, reuse and recycle.", "我们应该减少、重复使用和回收。"], ["Take quick showers to save water.", "快速淋浴节约用水。"]],
  },
];

function cleanWord(word) {
  return word.toLowerCase().replace(/[^a-z\s-]/g, "").trim();
}

function regularPastVerb(word) {
  if (word.endsWith("e")) return `${word}d`;
  if (word.endsWith("y") && !/[aeiou]y$/.test(word)) return `${word.slice(0, -1)}ied`;
  return `${word}ed`;
}

function getVerbForms(base, irregularMap) {
  const exact = irregularMap[base];
  if (exact) return exact;
  if (!base.includes(" ")) {
    return { past: regularPastVerb(base), participle: regularPastVerb(base) };
  }
  const parts = base.split(" ");
  const first = parts[0];
  const tail = parts.slice(1).join(" ");
  const firstExact = irregularMap[first];
  if (firstExact) {
    return {
      past: `${firstExact.past} ${tail}`.trim(),
      participle: `${firstExact.participle} ${tail}`.trim(),
    };
  }
  const reg = regularPastVerb(first);
  return { past: `${reg} ${tail}`.trim(), participle: `${reg} ${tail}`.trim() };
}

function buildBlankSentenceFromText(sentence, candidates) {
  for (const candidate of candidates) {
    const safe = candidate.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const re = new RegExp(`\\b${safe}\\b`, "i");
    if (re.test(sentence)) {
      return sentence.replace(re, "___");
    }
  }
  return "";
}

function pickKeyFromText(text) {
  const tokens = text.replace(/[^A-Za-z\s-]/g, " ").split(/\s+/).filter(Boolean);
  const preferred = tokens.find((token) => token.length >= 5);
  return preferred || tokens[tokens.length - 1] || text.split(" ")[0];
}

function findSentenceForWord(unit, part, word) {
  const sentencePool = part === "A" ? unit.partASentences : unit.partBSentences;
  const normalized = cleanWord(word);
  const found = sentencePool.find(([en]) => cleanWord(en).includes(normalized));
  if (found) return found;
  return sentencePool[0] || ["Let's learn this word.", "让我们学习这个单词。"];
}

function buildVocabularyCardsFromAppendix() {
  const cards = [];
  appendixUnits.forEach((unit) => {
    [["A", unit.partAVocab], ["B", unit.partBVocab]].forEach(([part, vocabList]) => {
      vocabList.forEach(([word, ipa, pos, zh]) => {
        const [example, exampleZh] = findSentenceForWord(unit, part, word);
        cards.push({
          unit: unit.num,
          category: `Part ${part} · ${pos}`,
          front: word,
          ipa,
          zh,
          example,
          exampleZh,
          image: unitLocalImage[unit.num],
        });
      });
    });
  });
  return cards;
}

function buildPhraseCardsFromAppendix() {
  const all = [];
  appendixUnits.forEach((unit) => {
    [["A", unit.partAPhrases, unit.partASentences], ["B", unit.partBPhrases, unit.partBSentences]].forEach(([part, phraseList, sentenceList]) => {
      phraseList.forEach(([en, zh]) => {
        all.push({ scene: `Unit ${unit.num} Part ${part}`, en, key: pickKeyFromText(en), zh });
      });
      sentenceList.forEach(([en, zh]) => {
        all.push({ scene: `Unit ${unit.num} Part ${part}`, en, key: pickKeyFromText(en), zh });
      });
    });
  });
  return all;
}

function buildVerbTriplesFromAppendix() {
  const irregular = {
    be: { past: "was/were", participle: "been" },
    go: { past: "went", participle: "gone" },
    see: { past: "saw", participle: "seen" },
    eat: { past: "ate", participle: "eaten" },
    take: { past: "took", participle: "taken" },
    run: { past: "ran", participle: "run" },
    wake: { past: "woke", participle: "woken" },
    begin: { past: "began", participle: "begun" },
    win: { past: "won", participle: "won" },
    buy: { past: "bought", participle: "bought" },
    spend: { past: "spent", participle: "spent" },
    come: { past: "came", participle: "come" },
    make: { past: "made", participle: "made" },
    send: { past: "sent", participle: "sent" },
    count: { past: "counted", participle: "counted" },
  };
  const seen = new Set();
  const triples = [];
  appendixUnits.forEach((unit) => {
    const unitSentences = [...unit.partASentences, ...unit.partBSentences];
    [["A", unit.partAVocab, unit.partASentences], ["B", unit.partBVocab, unit.partBSentences]].forEach(([part, vocabList, sentenceList]) => {
      vocabList.forEach(([word, , pos]) => {
        if (!pos.includes("v.")) return;
        if (pos.includes("modal")) return;
        const raw = word.toLowerCase();
        const base = (raw === "was" || raw === "were") ? "be" : raw;
        if (seen.has(base)) return;
        const forms = getVerbForms(base, irregular);
        const past = forms.past;
        const participle = forms.participle;
        const sample = [...sentenceList, ...unitSentences].find(([en]) => {
          const lower = cleanWord(en);
          if (base === "be") return lower.includes("was") || lower.includes("were") || lower.includes("am") || lower.includes("is") || lower.includes("are");
          return lower.includes(base) || lower.includes(String(past).replace("/", " "));
        }) || null;
        if (!sample) return;

        const displayBase = base === "be" ? "be (am/is/are)" : base;
        const fillAnswer = base === "be" ? "was/were" : past;
        const answerCandidates = base === "be"
          ? ["was", "were", "am", "is", "are"]
          : [String(past), base, String(participle)];
        const blankSentence = buildBlankSentenceFromText(sample[0], answerCandidates);
        if (!blankSentence) return;

        seen.add(base);
        triples.push({
          unit: unit.num,
          base: displayBase,
          past,
          participle,
          usage: `来自 Unit ${unit.num} Part ${part}`,
          sentence: `${sample[0]} / ${sample[1]}`,
          fillPrompt: `教材完整句子填空：${blankSentence}`,
          fillAnswer,
          fillClue: `中文提示：${sample[1]}`,
        });
      });
    });
  });
  return triples;
}

const vocabularyCards = buildVocabularyCardsFromAppendix();

const grammarPoints = [
  {
    title: "Unit 1 一般过去时",
    rule: "描述过去发生的事用过去式；否定用 didn't + 动词原形；疑问用 Did + 主语 + 动词原形。",
    examples: [
      "I climbed the Great Wall last weekend.",
      "Did you visit Xi'an? Yes, I did.",
      "I didn't take many photos.",
    ],
  },
  {
    title: "Unit 2 Did you...? 询问过去经历",
    rule: "询问过去是否做过某事：Did you + 动词原形 ...? 回答用 Yes, ... did / No, ... didn't。",
    examples: [
      "Did you eat mooncakes? Yes, we did.",
      "Did you take a trip? No, we didn't.",
      "What did you do for the Spring Festival?",
    ],
  },
  {
    title: "Unit 3 should / shouldn't",
    rule: "should 表示建议，后接动词原形；shouldn't 表示不应该。",
    examples: [
      "You should see a doctor.",
      "You should exercise every day.",
      "You shouldn't stay up late.",
    ],
  },
  {
    title: "Unit 4 be going to + 动词原形",
    rule: "表示计划或打算。",
    examples: [
      "I am going to save up for a computer.",
      "She is going to buy a schoolbag.",
      "We are going to write a spending plan.",
    ],
  },
  {
    title: "Unit 5 There is / There are + can",
    rule: "There is + 单数；There are + 复数；can + 动词原形表示能力。",
    examples: [
      "There is a rocket in the museum.",
      "There are eight planets in the solar system.",
      "We can use telescopes to look into space.",
    ],
  },
  {
    title: "Unit 6 Where does...come from? + should",
    rule: "询问来源：Where does + 单数主语 + come from? 提建议用 should。",
    examples: [
      "Where does electricity come from? It comes from power stations.",
      "Where does water come from? It comes from rivers.",
      "We should reduce, reuse and recycle.",
    ],
  },
  {
    title: "补充语法 1：一般现在时（三单）",
    rule: "主语是 he/she/it 或单数名词时，动词通常加 -s/-es。",
    examples: [
      "He likes science very much.",
      "She watches TV after dinner.",
      "The train goes to Beijing every day.",
    ],
  },
  {
    title: "补充语法 2：There be 就近原则",
    rule: "There be 句型中，be 动词与后面最近的名词保持一致。",
    examples: [
      "There is a book and two pens on the desk.",
      "There are two pens and a book on the desk.",
      "There is some water in the bottle.",
    ],
  },
  {
    title: "补充语法 3：特殊疑问词",
    rule: "what/where/when/how/why/how many/how much 根据提问对象选择。",
    examples: [
      "Where did you go yesterday?",
      "How many apples do you want?",
      "Why are you late for school?",
    ],
  },
  {
    title: "补充语法 4：情态动词 can / should",
    rule: "can / should 后都接动词原形，不加 to，不加 -s。",
    examples: [
      "I can swim very well.",
      "You should drink more water.",
      "He can help his classmates.",
    ],
  },
];

const commonPhrases = buildPhraseCardsFromAppendix();

const quizzes = [
  {
    id: "u1a-1",
    unit: 1,
    part: "A",
    badge: "Unit 1 Part A 旅行闯关",
    prompt: "选择正确句子：你上周六做了什么？",
    options: [
      "What do you do last Saturday?",
      "What did you do last Saturday?",
      "What did you did last Saturday?",
      "What were you do last Saturday?",
    ],
    answer: "What did you do last Saturday?",
    explainCorrect: "过去时提问结构是 What did + 主语 + 动词原形。",
    optionReasons: {
      "What do you do last Saturday?": "last Saturday 是过去时间，不能用 do。",
      "What did you do last Saturday?": "结构正确，did 后要用原形 do。",
      "What did you did last Saturday?": "did 后面不能再用过去式 did。",
      "What were you do last Saturday?": "were + do 结构错误。",
    },
  },
  {
    id: "u1b-1",
    unit: 1,
    part: "B",
    badge: "Unit 1 Part B 旅行闯关",
    prompt: "We ___ to see the Terracotta Warriors.",
    options: ["go", "went", "gone", "going"],
    answer: "went",
    explainCorrect: "句子描述过去经历，go 用过去式 went。",
    optionReasons: {
      go: "一般现在时原形，不符合过去语境。",
      went: "正确，go 的过去式。",
      gone: "gone 是过去分词，不能单独作谓语。",
      going: "现在分词不能单独作谓语。",
    },
  },
  {
    id: "u2a-1",
    unit: 2,
    part: "A",
    badge: "Unit 2 Part A 节日闯关",
    prompt: "Did you eat mooncakes? 的否定回答是：",
    options: ["No, we didn't.", "No, we don't.", "No, we not.", "No, we aren't."],
    answer: "No, we didn't.",
    explainCorrect: "Did 引导的一般过去时问句，否定答语要用 didn't。",
    optionReasons: {
      "No, we didn't.": "正确，时态匹配。",
      "No, we don't.": "don't 是一般现在时。",
      "No, we not.": "缺少助动词，句子不完整。",
      "No, we aren't.": "be 动词答法，不适用于 eat。",
    },
  },
  {
    id: "u2b-1",
    unit: 2,
    part: "B",
    badge: "Unit 2 Part B 节日闯关",
    prompt: "Finally, his team ___ the race!",
    options: ["win", "wins", "won", "winning"],
    answer: "won",
    explainCorrect: "过去发生的结果用一般过去时，win 的过去式是 won。",
    optionReasons: {
      win: "原形不符合过去时。",
      wins: "第三人称单数一般现在时，不符合句意。",
      won: "正确，win 的过去式。",
      winning: "现在分词不可单独作谓语。",
    },
  },
  {
    id: "u3a-1",
    unit: 3,
    part: "A",
    badge: "Unit 3 Part A 健康闯关",
    prompt: "选择最合适建议：He has a fever.",
    options: ["He should see a doctor.", "He should stayed up late.", "He should to drink water.", "He should not goes home."],
    answer: "He should see a doctor.",
    explainCorrect: "should 后接动词原形，且语义上“发烧要看医生”。",
    optionReasons: {
      "He should see a doctor.": "语法和语义都正确。",
      "He should stayed up late.": "should 后不能接过去式 stayed。",
      "He should to drink water.": "should 后不能加 to。",
      "He should not goes home.": "should not 后应接 go 原形。",
    },
  },
  {
    id: "u3b-1",
    unit: 3,
    part: "B",
    badge: "Unit 3 Part B 健康闯关",
    prompt: "I ___ going to see a doctor.",
    options: ["am", "is", "are", "be"],
    answer: "am",
    explainCorrect: "主语 I 对应 be 动词 am，构成 be going to。",
    optionReasons: {
      am: "正确：I am going to...",
      is: "is 搭配 he/she/it。",
      are: "are 不搭配 I。",
      be: "be 是原形，不能直接放在主语后。",
    },
  },
  {
    id: "u4a-1",
    unit: 4,
    part: "A",
    badge: "Unit 4 Part A 理财闯关",
    prompt: "How are you going to ___ your pocket money?",
    options: ["spend", "spent", "spending", "spends"],
    answer: "spend",
    explainCorrect: "be going to 后接动词原形，应该用 spend。",
    optionReasons: {
      spend: "正确，动词原形。",
      spent: "过去式，不符合 be going to 结构。",
      spending: "现在分词，不符合结构。",
      spends: "第三人称单数形式，不符合结构。",
    },
  },
  {
    id: "u4b-1",
    unit: 4,
    part: "B",
    badge: "Unit 4 Part B 理财闯关",
    prompt: "I ___ to save more.",
    options: ["need", "needs", "needed", "needing"],
    answer: "need",
    explainCorrect: "主语 I 在一般现在时中搭配动词原形 need。",
    optionReasons: {
      need: "正确，I need to ...",
      needs: "needs 用于第三人称单数。",
      needed: "过去式不符合当前语境。",
      needing: "分词不能单独作谓语。",
    },
  },
  {
    id: "u5a-1",
    unit: 5,
    part: "A",
    badge: "Unit 5 Part A 太空闯关",
    prompt: "There ___ eight planets in our solar system.",
    options: ["is", "are", "be", "am"],
    answer: "are",
    explainCorrect: "eight planets 是复数名词，There be 句型要用 are。",
    optionReasons: {
      is: "is 搭配单数。",
      are: "正确，复数搭配 are。",
      be: "原形不能直接作谓语。",
      am: "am 只搭配 I，不用于 There be。",
    },
  },
  {
    id: "u5b-1",
    unit: 5,
    part: "B",
    badge: "Unit 5 Part B 太空闯关",
    prompt: "China ___ a rover to Mars last year.",
    options: ["send", "sends", "sent", "sending"],
    answer: "sent",
    explainCorrect: "last year 明确过去时间，send 用过去式 sent。",
    optionReasons: {
      send: "原形不符合过去时间。",
      sends: "一般现在时第三人称单数，不符合语境。",
      sent: "正确，send 的过去式。",
      sending: "分词不能单独作谓语。",
    },
  },
  {
    id: "u6a-1",
    unit: 6,
    part: "A",
    badge: "Unit 6 Part A 环保闯关",
    prompt: "Where does electricity come from? — It ___ from power stations.",
    options: ["come", "comes", "came", "coming"],
    answer: "comes",
    explainCorrect: "主语 it 是第三人称单数，一般现在时动词加 -s。",
    optionReasons: {
      come: "第三人称单数不能用原形。",
      comes: "正确：It comes from...",
      came: "过去式，不符合一般事实表达。",
      coming: "分词不能单独作谓语。",
    },
  },
  {
    id: "u6b-1",
    unit: 6,
    part: "B",
    badge: "Unit 6 Part B 环保闯关",
    prompt: "We should ___, reuse and recycle.",
    options: ["reduce", "reduces", "reduced", "reducing"],
    answer: "reduce",
    explainCorrect: "should 后面必须接动词原形。",
    optionReasons: {
      reduce: "正确，动词原形。",
      reduces: "第三人称单数形式错误。",
      reduced: "过去式错误。",
      reducing: "分词形式错误。",
    },
  },
];

const verbTriples = buildVerbTriplesFromAppendix();

const writingSamples = [
  { unit: 1, title: "Unit 1 范文1：My Amazing Trip", en: "Last holiday, I went to Beijing with my parents. We climbed the Great Wall and took many photos. The view was amazing and we had a great time there.", zh: "上个假期，我和父母去了北京。我们爬了长城并拍了很多照片。风景很棒，我们玩得很开心。", fillPrompt: "填空：We ___ the Great Wall and took many photos.", fillAnswer: "climbed" },
  { unit: 1, title: "Unit 1 范文2：A Visit to Xi'an", en: "Over the summer holidays, my family went to Xi'an. We visited the Terracotta Warriors and ate Xi'an noodles. It was an inspiring trip for me.", zh: "暑假期间，我家去了西安。我们参观了兵马俑，还吃了西安面。这趟旅行很鼓舞我。", fillPrompt: "填空：We visited the Terracotta Warriors and ___ Xi'an noodles.", fillAnswer: "ate" },
  { unit: 1, title: "Unit 1 范文3：Postcard to My Friend", en: "Hi Amy, I am in New Zealand now. Yesterday I visited the Gingerbread House. Please come here one day. I will send you more pictures.", zh: "嗨，Amy，我现在在新西兰。昨天我参观了姜饼屋。希望你有一天也来。我会发给你更多照片。", fillPrompt: "填空：I will ___ you more pictures.", fillAnswer: "send" },
  { unit: 2, title: "Unit 2 范文1：My Spring Festival", en: "The Spring Festival is my favourite festival. We cleaned the house, pasted fu on the door and had a big dinner. We also counted down to the new year.", zh: "春节是我最喜欢的节日。我们打扫房子、贴福字、吃年夜饭，还倒计时迎接新年。", fillPrompt: "填空：We cleaned the house and ___ fu on the door.", fillAnswer: "pasted" },
  { unit: 2, title: "Unit 2 范文2：A Happy Mid-Autumn Festival", en: "On Mid-Autumn Festival, my family got together. We ate mooncakes and watched the moon. I talked with my grandparents and felt very happy.", zh: "中秋节时，我们全家团聚。我们吃月饼、赏月。我和爷爷奶奶聊天，感到非常开心。", fillPrompt: "填空：We ___ mooncakes and watched the moon.", fillAnswer: "ate" },
  { unit: 2, title: "Unit 2 范文3：Dragon Boat Day", en: "Last Dragon Boat Festival, we woke up early and watched the dragon boat race. My mother made zongzi and we cheered for the teams.", zh: "上个端午节，我们早起看龙舟赛。妈妈包了粽子，我们为队伍加油。", fillPrompt: "填空：My mother ___ zongzi and we cheered for the teams.", fillAnswer: "made" },
  { unit: 3, title: "Unit 3 范文1：How to Keep Healthy", en: "We should have a healthy diet and exercise often. We shouldn't stay up late. If we feel ill, we should see a doctor in time.", zh: "我们应该健康饮食并经常锻炼，不应熬夜。如果不舒服，应及时看医生。", fillPrompt: "填空：If we feel ill, we should ___ a doctor.", fillAnswer: "see" },
  { unit: 3, title: "Unit 3 范文2：My Healthy Plan", en: "I am going to run for twenty minutes every day. I will eat more vegetables and fruit. I am not going to drink too much cola.", zh: "我打算每天跑步二十分钟。我会多吃蔬菜水果，不会喝太多可乐。", fillPrompt: "填空：I am going to ___ for twenty minutes every day.", fillAnswer: "run" },
  { unit: 3, title: "Unit 3 范文3：A Visit to the Doctor", en: "Yesterday I had a fever and a cough. My mum took me to hospital. The doctor said I should drink warm water and get enough sleep.", zh: "昨天我发烧并咳嗽。妈妈带我去了医院。医生说我应该喝温水并保证睡眠。", fillPrompt: "填空：The doctor said I should ___ warm water.", fillAnswer: "drink" },
  { unit: 4, title: "Unit 4 范文1：My Pocket Money Plan", en: "I get pocket money every month. I save half of it first. Then I buy books and school things. I don't buy things I don't need.", zh: "我每个月有零花钱。我先存下一半，然后买书和学习用品，不买不需要的东西。", fillPrompt: "填空：I ___ half of my pocket money first.", fillAnswer: "save" },
  { unit: 4, title: "Unit 4 范文2：Smart Shopping", en: "I want a new schoolbag, but I will wait for a sale. I make a spending plan before shopping. It helps me use money wisely.", zh: "我想要一个新书包，但我会等打折再买。购物前我会做花钱计划，这样能更合理用钱。", fillPrompt: "填空：I will wait for a ___.", fillAnswer: "sale" },
  { unit: 4, title: "Unit 4 范文3：Need and Want", en: "I need a dictionary for school, but I only want a toy car. I decide to buy the dictionary first. This is a better money plan.", zh: "我需要一本词典上学用，但我只是想要玩具车。我决定先买词典，这是更好的用钱计划。", fillPrompt: "填空：I ___ a dictionary for school.", fillAnswer: "need" },
  { unit: 5, title: "Unit 5 范文1：My Dream of Space", en: "I am interested in space. There are many planets in the solar system. I want to be an astronaut in the future.", zh: "我对太空感兴趣。太阳系有很多行星。未来我想成为宇航员。", fillPrompt: "填空：I want to be an ___ in the future.", fillAnswer: "astronaut" },
  { unit: 5, title: "Unit 5 范文2：A Visit to a Space Museum", en: "Last weekend, I visited a space museum. I saw a big rocket and learned about Mars rovers. The trip was exciting.", zh: "上周末我参观了太空博物馆。我看到了大火箭，还了解了火星探测器。这次旅行非常刺激。", fillPrompt: "填空：I ___ a big rocket in the museum.", fillAnswer: "saw" },
  { unit: 5, title: "Unit 5 范文3：Exploring Mars", en: "China sent a rover to Mars. It can take pictures and study the soil. I am proud of our space science.", zh: "中国向火星发射了探测器。它可以拍照并研究土壤。我为我们的航天科技感到自豪。", fillPrompt: "填空：China ___ a rover to Mars.", fillAnswer: "sent" },
  { unit: 6, title: "Unit 6 范文1：Save Energy Every Day", en: "We should save energy every day. We should turn off lights when we leave a room and unplug computers.", zh: "我们应该每天节约能源。离开房间时要关灯，并拔掉电脑插头。", fillPrompt: "填空：We should ___ off lights when we leave.", fillAnswer: "turn" },
  { unit: 6, title: "Unit 6 范文2：Green Energy", en: "Solar power and wind power are green energy. They are clean and helpful for our Earth. We should use more green energy.", zh: "太阳能和风能是绿色能源。它们清洁环保，对地球有帮助。我们应该多用绿色能源。", fillPrompt: "填空：Solar power and wind power are ___ energy.", fillAnswer: "green" },
  { unit: 6, title: "Unit 6 范文3：3R Rules", en: "To protect the Earth, we should reduce, reuse and recycle. I reuse my school bags and recycle paper bottles at school.", zh: "为了保护地球，我们应减少、重复使用和回收。我会重复使用书包，并在学校回收纸和瓶子。", fillPrompt: "填空：We should reduce, ___ and recycle.", fillAnswer: "reuse" },
];

const STORAGE_KEY = "english_grade6_trainer_stats_v3";
const WRONG_BOOK_KEY = "english_grade6_wrong_quiz_ids_v1";
const PROFILE_KEY = "english_grade6_profile_v1";
const CHALLENGE_LOG_KEY = "english_grade6_challenge_logs_v1";
const REDEEM_LOG_KEY = "english_grade6_redeem_logs_v1";
const JOURNAL_KEY = "english_grade6_journal_v1";
const WRONG_BOOK_ITEMS_KEY = "english_grade6_wrong_items_v1";
const LEADERBOARD_KEY = "english_grade6_leaderboard_v1";
const BEHAVIOR_LOG_KEY = "english_grade6_behavior_logs_v1";
const BADGE_KEY = "english_grade6_badges_v1";

const svoExercises = [
  { sentenceHint: "I visited the museum yesterday.", subject: "I", verb: "visited", object: "the museum yesterday" },
  { sentenceHint: "We should save energy every day.", subject: "We", verb: "should save", object: "energy every day" },
  { sentenceHint: "They are going to buy books.", subject: "They", verb: "are going to buy", object: "books" },
  { sentenceHint: "China sent a rover to Mars.", subject: "China", verb: "sent", object: "a rover to Mars" },
  { sentenceHint: "My mum cleaned the house.", subject: "My mum", verb: "cleaned", object: "the house" },
];

const behaviorActions = [
  { id: "help_others", label: "乐于助人 +200", points: 200, category: "good" },
  { id: "homework_star", label: "作业优星 +300", points: 300, category: "good" },
  { id: "reading_clock", label: "阅读打卡 +150", points: 150, category: "good" },
  { id: "english_speak", label: "主动英语表达 +250", points: 250, category: "good" },
  { id: "tidy_room", label: "整理房间 +100", points: 100, category: "good" },
  { id: "wash_tidy", label: "洗漱整理 +100", points: 100, category: "good" },
  { id: "exercise", label: "运动锻炼 +100", points: 100, category: "good" },
  { id: "family_help", label: "家务帮助 +150", points: 150, category: "good" },
  { id: "class_answer", label: "课堂积极回答 +150", points: 150, category: "good" },
  { id: "dictation_full", label: "听写满分 +200", points: 200, category: "good" },
  { id: "review_notes", label: "自主复习 +100", points: 100, category: "good" },
  { id: "good_sleep", label: "早睡早起 +100", points: 100, category: "good" },
  { id: "kindness", label: "文明礼貌 +100", points: 100, category: "good" },
  { id: "goal_done", label: "完成学习目标 +200", points: 200, category: "good" },
  { id: "focus_30", label: "专注学习30分钟 +200", points: 200, category: "good" },
  { id: "watch_tv", label: "看电视超时 -150", points: -150, category: "bad" },
  { id: "play_game", label: "玩游戏超时 -200", points: -200, category: "bad" },
  { id: "late_sleep", label: "熬夜 -150", points: -150, category: "bad" },
  { id: "homework_delay", label: "作业拖延 -200", points: -200, category: "bad" },
  { id: "argue", label: "顶嘴争吵 -150", points: -150, category: "bad" },
  { id: "messy_room", label: "房间杂乱 -100", points: -100, category: "bad" },
  { id: "snack_too_much", label: "零食过量 -100", points: -100, category: "bad" },
  { id: "late_arrive", label: "迟到 -100", points: -100, category: "bad" },
  { id: "no_review", label: "未复习 -100", points: -100, category: "bad" },
];

let cardIndex = 0;
let cardFlipped = false;
let grammarIndex = 0;
let phraseIndex = 0;
let phraseFlipped = false;
let writingIndex = 0;
let filteredWritingSamples = writingSamples.filter((item) => item.unit === 1);
let currentQuiz = null;
let verbIndex = 0;
let svoIndex = 0;
let activeSvoSlot = "subject";
let svoUserAnswer = { subject: "", verb: "", object: "" };
let filteredCards = [...vocabularyCards];
let filteredQuizzes = [...quizzes];
let wrongBookMode = false;
let stats = loadStats();
let wrongQuizIds = loadWrongQuizIds();
let studentProfile = loadStudentProfile();
let challengeLogs = loadChallengeLogs();
let redeemLogs = loadRedeemLogs();
let journalEntries = loadJournalEntries();
let wrongBookItems = loadWrongBookItems();
let leaderboard = loadLeaderboard();
let behaviorLogs = loadBehaviorLogs();
let badges = loadBadges();
let currentFillQuestions = [];

const elements = {
  correctCount: document.getElementById("correctCount"),
  wrongCount: document.getElementById("wrongCount"),
  attemptCount: document.getElementById("attemptCount"),
  accuracy: document.getElementById("accuracy"),
  pointCount: document.getElementById("pointCount"),
  cumulativePointCount: document.getElementById("cumulativePointCount"),
  wrongBookCount: document.getElementById("wrongBookCount"),
  nicknameInput: document.getElementById("nicknameInput"),
  saveNickname: document.getElementById("saveNickname"),
  resetAllStats: document.getElementById("resetAllStats"),
  exportReport: document.getElementById("exportReport"),
  exportReportHtml: document.getElementById("exportReportHtml"),
  exportPointsHtml: document.getElementById("exportPointsHtml"),
  markAnswerCorrect: document.getElementById("markAnswerCorrect"),
  markAnswerWrong: document.getElementById("markAnswerWrong"),
  nicknameDisplay: document.getElementById("nicknameDisplay"),
  lastPracticeTime: document.getElementById("lastPracticeTime"),
  redeemName: document.getElementById("redeemName"),
  redeemCost: document.getElementById("redeemCost"),
  redeemPoints: document.getElementById("redeemPoints"),
  leaderboardList: document.getElementById("leaderboardList"),
  leaderboardSort: document.getElementById("leaderboardSort"),
  behaviorActionSelect: document.getElementById("behaviorActionSelect"),
  applyBehaviorAction: document.getElementById("applyBehaviorAction"),
  badgeList: document.getElementById("badgeList"),
  redeemList: document.getElementById("redeemList"),
  wrongItemList: document.getElementById("wrongItemList"),
  exportFeedback: document.getElementById("exportFeedback"),
  challengeList: document.getElementById("challengeList"),
  fxLayer: document.getElementById("fxLayer"),
  tabs: document.querySelectorAll(".tab"),
  panels: document.querySelectorAll(".panel"),
  unitFilter: document.getElementById("unitFilter"),
  flashcard: document.getElementById("flashcard"),
  cardCategory: document.getElementById("cardCategory"),
  cardFront: document.getElementById("cardFront"),
  cardBack: document.getElementById("cardBack"),
  cardPhonetic: document.getElementById("cardPhonetic"),
  cardZh: document.getElementById("cardZh"),
  cardExample: document.getElementById("cardExample"),
  cardExampleZh: document.getElementById("cardExampleZh"),
  cardImage: document.getElementById("cardImage"),
  prevCard: document.getElementById("prevCard"),
  nextCard: document.getElementById("nextCard"),
  grammarTitle: document.getElementById("grammarTitle"),
  grammarRule: document.getElementById("grammarRule"),
  grammarExample: document.getElementById("grammarExample"),
  nextGrammar: document.getElementById("nextGrammar"),
  svoSentenceHint: document.getElementById("svoSentenceHint"),
  slotSubject: document.getElementById("slotSubject"),
  slotVerb: document.getElementById("slotVerb"),
  slotObject: document.getElementById("slotObject"),
  svoTokens: document.getElementById("svoTokens"),
  checkSvo: document.getElementById("checkSvo"),
  nextSvo: document.getElementById("nextSvo"),
  svoFeedback: document.getElementById("svoFeedback"),
  phraseScene: document.getElementById("phraseScene"),
  phraseCard: document.getElementById("phraseCard"),
  phraseMasked: document.getElementById("phraseMasked"),
  phraseEn: document.getElementById("phraseEn"),
  phraseZh: document.getElementById("phraseZh"),
  phraseHint: document.getElementById("phraseHint"),
  nextPhrase: document.getElementById("nextPhrase"),
  writingTitle: document.getElementById("writingTitle"),
  writingEn: document.getElementById("writingEn"),
  writingZh: document.getElementById("writingZh"),
  writingUnitFilter: document.getElementById("writingUnitFilter"),
  writingFillPrompt: document.getElementById("writingFillPrompt"),
  writingFillInput: document.getElementById("writingFillInput"),
  checkWritingFill: document.getElementById("checkWritingFill"),
  writingFillFeedback: document.getElementById("writingFillFeedback"),
  writingStudentInput: document.getElementById("writingStudentInput"),
  scoreWriting: document.getElementById("scoreWriting"),
  writingScore: document.getElementById("writingScore"),
  writingAdvice: document.getElementById("writingAdvice"),
  nextWriting: document.getElementById("nextWriting"),
  quizUnitFilter: document.getElementById("quizUnitFilter"),
  quizPartFilter: document.getElementById("quizPartFilter"),
  startWrongBook: document.getElementById("startWrongBook"),
  clearWrongBook: document.getElementById("clearWrongBook"),
  wrongBookStatus: document.getElementById("wrongBookStatus"),
  quizBadge: document.getElementById("quizBadge"),
  quizPrompt: document.getElementById("quizPrompt"),
  quizOptions: document.getElementById("quizOptions"),
  quizFeedback: document.getElementById("quizFeedback"),
  quizAnalysis: document.getElementById("quizAnalysis"),
  nextQuestion: document.getElementById("nextQuestion"),
  fillUnitFilter: document.getElementById("fillUnitFilter"),
  fillQuestions: document.getElementById("fillQuestions"),
  submitFillSet: document.getElementById("submitFillSet"),
  nextFillSet: document.getElementById("nextFillSet"),
  fillSetFeedback: document.getElementById("fillSetFeedback"),
  verbBase: document.getElementById("verbBase"),
  verbInfinitive: document.getElementById("verbInfinitive"),
  verbPast: document.getElementById("verbPast"),
  verbParticiple: document.getElementById("verbParticiple"),
  verbUsage: document.getElementById("verbUsage"),
  verbSentence: document.getElementById("verbSentence"),
  verbFillPrompt: document.getElementById("verbFillPrompt"),
  verbFillInput: document.getElementById("verbFillInput"),
  checkVerb: document.getElementById("checkVerb"),
  nextVerb: document.getElementById("nextVerb"),
  verbFeedback: document.getElementById("verbFeedback"),
  appendixSummary: document.getElementById("appendixSummary"),
  appendixTable: document.getElementById("appendixTable"),
  refreshAppendix: document.getElementById("refreshAppendix"),
  journalToday: document.getElementById("journalToday"),
  journalInput: document.getElementById("journalInput"),
  saveJournal: document.getElementById("saveJournal"),
  journalFeedback: document.getElementById("journalFeedback"),
  journalList: document.getElementById("journalList"),
};

function loadStats() {
  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return { correct: 0, wrong: 0, attempts: 0, points: 0, highestPoints: 0, accumulatedPoints: 0, lastPracticeAt: "", lastCompoundDate: "", lastSpendDate: "" };
  }
  try {
    const parsed = JSON.parse(raw);
    return {
      correct: Number(parsed.correct) || 0,
      wrong: Number(parsed.wrong) || 0,
      attempts: Number(parsed.attempts) || 0,
      points: Number(parsed.points) || 0,
      highestPoints: Number(parsed.highestPoints) || 0,
      accumulatedPoints: Number(parsed.accumulatedPoints) || Number(parsed.highestPoints) || 0,
      lastPracticeAt: parsed.lastPracticeAt || "",
      lastCompoundDate: parsed.lastCompoundDate || "",
      lastSpendDate: parsed.lastSpendDate || "",
    };
  } catch {
    return { correct: 0, wrong: 0, attempts: 0, points: 0, highestPoints: 0, accumulatedPoints: 0, lastPracticeAt: "", lastCompoundDate: "", lastSpendDate: "" };
  }
}

function loadWrongQuizIds() {
  const raw = window.localStorage.getItem(WRONG_BOOK_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function loadStudentProfile() {
  const raw = window.localStorage.getItem(PROFILE_KEY);
  if (!raw) return { nickname: "同学" };
  try {
    const parsed = JSON.parse(raw);
    return { nickname: parsed.nickname || "同学" };
  } catch {
    return { nickname: "同学" };
  }
}

function loadChallengeLogs() {
  const raw = window.localStorage.getItem(CHALLENGE_LOG_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function loadRedeemLogs() {
  const raw = window.localStorage.getItem(REDEEM_LOG_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function loadJournalEntries() {
  const raw = window.localStorage.getItem(JOURNAL_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function loadWrongBookItems() {
  const raw = window.localStorage.getItem(WRONG_BOOK_ITEMS_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function loadLeaderboard() {
  const raw = window.localStorage.getItem(LEADERBOARD_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((row) => ({
      nickname: row.nickname || "同学",
      bestPoints: Number(row.bestPoints) || 0,
      bestAccuracy: Number(row.bestAccuracy) || 0,
      bestStreakDays: Number(row.bestStreakDays) || 0,
      updatedAt: row.updatedAt || nowText(),
    }));
  } catch {
    return [];
  }
}

function loadBehaviorLogs() {
  const raw = window.localStorage.getItem(BEHAVIOR_LOG_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function loadBadges() {
  const raw = window.localStorage.getItem(BADGE_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveStats() {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
}

function saveWrongQuizIds() {
  window.localStorage.setItem(WRONG_BOOK_KEY, JSON.stringify(wrongQuizIds));
}

function saveStudentProfile() {
  window.localStorage.setItem(PROFILE_KEY, JSON.stringify(studentProfile));
}

function saveChallengeLogs() {
  window.localStorage.setItem(CHALLENGE_LOG_KEY, JSON.stringify(challengeLogs));
}

function saveRedeemLogs() {
  window.localStorage.setItem(REDEEM_LOG_KEY, JSON.stringify(redeemLogs));
}

function saveJournalEntries() {
  window.localStorage.setItem(JOURNAL_KEY, JSON.stringify(journalEntries));
}

function saveWrongBookItems() {
  window.localStorage.setItem(WRONG_BOOK_ITEMS_KEY, JSON.stringify(wrongBookItems));
}

function saveLeaderboard() {
  window.localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(leaderboard));
}

function saveBehaviorLogs() {
  window.localStorage.setItem(BEHAVIOR_LOG_KEY, JSON.stringify(behaviorLogs));
}

function saveBadges() {
  window.localStorage.setItem(BADGE_KEY, JSON.stringify(badges));
}

function nowText() {
  return new Date().toLocaleString("zh-CN", { hour12: false });
}

function formatDate(dateObj) {
  return dateObj.toISOString().slice(0, 10);
}

function dateKeyFromText(text) {
  const m = String(text || "").match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
  if (!m) return "";
  const y = m[1];
  const mm = m[2].padStart(2, "0");
  const dd = m[3].padStart(2, "0");
  return `${y}-${mm}-${dd}`;
}

function buildPracticeDateKeys() {
  const set = new Set();
  if (stats.lastPracticeAt) {
    const key = dateKeyFromText(stats.lastPracticeAt);
    if (key) set.add(key);
  }
  challengeLogs.forEach((log) => {
    const key = dateKeyFromText(log.time);
    if (key) set.add(key);
  });
  return [...set].sort();
}

function calculateCurrentStreakDays() {
  const keys = buildPracticeDateKeys();
  if (keys.length === 0) return 0;
  const keySet = new Set(keys);
  let cursor = new Date();
  let streak = 0;
  while (true) {
    const key = formatDate(cursor);
    if (!keySet.has(key)) {
      if (streak === 0) {
        cursor.setDate(cursor.getDate() - 1);
        const yesterday = formatDate(cursor);
        if (!keySet.has(yesterday)) return 0;
        streak += 1;
      } else break;
    } else {
      streak += 1;
    }
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

function addWrongBookItem(moduleName, prompt, answer) {
  wrongBookItems.unshift({
    time: nowText(),
    module: moduleName,
    prompt,
    answer,
  });
  wrongBookItems = wrongBookItems.slice(0, 300);
  saveWrongBookItems();
  if (elements.wrongItemList) renderWrongBookItems();
}

function renderWrongBookItems() {
  if (wrongBookItems.length === 0) {
    elements.wrongItemList.textContent = "暂无错题自动收集";
    return;
  }
  elements.wrongItemList.innerHTML = wrongBookItems
    .slice(0, 40)
    .map((item) => `<div>${item.time} | ${item.module} | ${item.prompt} | 正解: ${item.answer}</div>`)
    .join("");
}

function updateLeaderboard() {
  const accuracy = stats.attempts === 0 ? 0 : Math.round((stats.correct / stats.attempts) * 100);
  const streakDays = calculateCurrentStreakDays();
  const existing = leaderboard.find((row) => row.nickname === studentProfile.nickname);
  const payload = {
    nickname: studentProfile.nickname,
    bestPoints: Math.max(stats.highestPoints, stats.points),
    bestAccuracy: accuracy,
    bestStreakDays: streakDays,
    updatedAt: nowText(),
  };
  if (!existing) leaderboard.push(payload);
  else {
    existing.bestPoints = Math.max(existing.bestPoints, payload.bestPoints);
    existing.bestAccuracy = Math.max(existing.bestAccuracy, payload.bestAccuracy);
    existing.bestStreakDays = Math.max(existing.bestStreakDays || 0, payload.bestStreakDays);
    existing.updatedAt = payload.updatedAt;
  }
  saveLeaderboard();
}

function renderLeaderboard() {
  const mode = elements.leaderboardSort?.value || "points";
  const sorter = {
    points: (a, b) => (b.bestPoints - a.bestPoints) || (b.bestAccuracy - a.bestAccuracy) || ((b.bestStreakDays || 0) - (a.bestStreakDays || 0)),
    accuracy: (a, b) => (b.bestAccuracy - a.bestAccuracy) || (b.bestPoints - a.bestPoints) || ((b.bestStreakDays || 0) - (a.bestStreakDays || 0)),
    streak: (a, b) => ((b.bestStreakDays || 0) - (a.bestStreakDays || 0)) || (b.bestPoints - a.bestPoints) || (b.bestAccuracy - a.bestAccuracy),
  }[mode];
  const top3 = [...leaderboard]
    .sort(sorter)
    .slice(0, 3);
  if (top3.length === 0) {
    elements.leaderboardList.textContent = "暂无排行数据";
    return;
  }
  elements.leaderboardList.innerHTML = top3
    .map((row, idx) => `<div>#${idx + 1} ${row.nickname} | 最佳积分 ${row.bestPoints} | 最佳正确率 ${row.bestAccuracy}% | 连续打卡 ${row.bestStreakDays || 0} 天 | ${row.updatedAt}</div>`)
    .join("");
}

function populateBehaviorActions() {
  elements.behaviorActionSelect.innerHTML = behaviorActions
    .map((item) => `<option value="${item.id}">${item.label}</option>`)
    .join("");
}

function applyBehaviorAction() {
  const selectedId = elements.behaviorActionSelect.value;
  const action = behaviorActions.find((item) => item.id === selectedId);
  if (!action) return;
  adjustPoints(action.points);
  markPractice();
  stats.attempts += 1;
  if (action.points > 0) stats.correct += 1;
  else stats.wrong += 1;
  behaviorLogs.unshift({ time: nowText(), ...action });
  behaviorLogs = behaviorLogs.slice(0, 500);
  saveBehaviorLogs();
  addChallengeLog("行为积分", action.label, action.points);
  if (action.points > 0) showSuccessFx();
  else showFailFx();
  checkAndGrantBadges();
  saveStats();
  updateDashboard();
  renderChallengeLogs();
  renderBadgeList();
  renderCharts();
}

function applyCompoundInterestIfNeeded() {
  const today = formatDate(new Date());
  const lastDate = stats.lastCompoundDate || today;
  if (!stats.lastCompoundDate) {
    stats.lastCompoundDate = today;
    saveStats();
    return;
  }
  if (today <= lastDate) return;
  const last = new Date(`${lastDate}T00:00:00`);
  const now = new Date(`${today}T00:00:00`);
  const days = Math.max(0, Math.floor((now - last) / 86400000));
  if (days === 0 || stats.points <= 0) {
    stats.lastCompoundDate = today;
    saveStats();
    return;
  }
  if (stats.lastSpendDate && stats.lastSpendDate >= lastDate) {
    stats.lastCompoundDate = today;
    saveStats();
    return;
  }
  const bonus = Math.floor(stats.points * (Math.pow(1.001, days) - 1));
  if (bonus > 0) {
    stats.points += bonus;
    stats.accumulatedPoints = (stats.accumulatedPoints || 0) + bonus;
    stats.highestPoints = Math.max(stats.highestPoints, stats.points);
    addChallengeLog("复利奖励", `每日千分之一 × ${days}天`, bonus);
  }
  stats.lastCompoundDate = today;
  saveStats();
}

function checkAndGrantBadges() {
  const addBadge = (id, name) => {
    if (badges.some((b) => b.id === id)) return;
    badges.push({ id, name, earnedAt: nowText() });
  };
  if (stats.points >= 300) addBadge("start_star", "🚀起步之星");
  if (stats.points >= 800) addBadge("growth_master", "🏆成长达人");
  if (stats.points >= 1500) addBadge("wealth_guard", "💎理财小能手");

  const washLogs = behaviorLogs.filter((l) => l.id === "wash_tidy").slice(0, 7);
  const daySet = new Set(washLogs.map((l) => l.time.slice(0, 10)));
  if (daySet.size >= 3) addBadge("tooth_guard", "🪥洁牙卫士");
  if (daySet.size >= 5) addBadge("habit_king", "🌟习惯王者");
  saveBadges();
}

function renderBadgeList() {
  if (badges.length === 0) {
    elements.badgeList.textContent = "暂无勋章";
    return;
  }
  elements.badgeList.innerHTML = badges
    .map((b) => `<span class="badge-chip">${b.name} (${b.earnedAt.slice(0, 10)})</span>`)
    .join(" ");
}

function renderCharts() {
  // 用户要求最终版移除积分趋势图和消费饼图。
}

function downloadTextFile(filename, content, mimeType = "text/plain") {
  const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function exportLearningReport() {
  const accuracy = stats.attempts === 0 ? 0 : Math.round((stats.correct / stats.attempts) * 100);
  const lines = [
    `学生昵称: ${studentProfile.nickname}`,
    `导出时间: ${nowText()}`,
    `答对: ${stats.correct}`,
    `答错: ${stats.wrong}`,
    `总答题: ${stats.attempts}`,
    `正确率: ${accuracy}%`,
    `当前积分: ${stats.points}`,
    `累积积分: ${stats.accumulatedPoints || 0}`,
    `错题本数量: ${wrongBookItems.length}`,
    "",
    "=== 最近挑战记录 ===",
    ...challengeLogs.slice(0, 50).map((i) => `${i.time} | ${i.item} | ${i.result} | ${i.pointDelta}`),
    "",
    "=== 兑换记录 ===",
    ...redeemLogs.slice(0, 50).map((i) => `${i.time} | ${i.name} | ${i.cost}`),
    "",
    "=== 错题本 ===",
    ...wrongBookItems.slice(0, 80).map((i) => `${i.time} | ${i.module} | ${i.prompt} | ${i.answer}`),
    "",
    "=== 学习日志 ===",
    ...journalEntries.map((i) => `${i.date} | ${i.text}`),
  ];
  downloadTextFile(`学习报告_${studentProfile.nickname}_${todayKey()}.txt`, lines.join("\n"));
  elements.exportFeedback.textContent = "学习报告已导出（TXT）。";
}

function exportPrintableHtmlReport() {
  const accuracy = stats.attempts === 0 ? 0 : Math.round((stats.correct / stats.attempts) * 100);
  const topRows = [...leaderboard]
    .sort((a, b) => (b.bestPoints - a.bestPoints) || (b.bestAccuracy - a.bestAccuracy) || ((b.bestStreakDays || 0) - (a.bestStreakDays || 0)))
    .slice(0, 3)
    .map((r, idx) => `<tr><td>${idx + 1}</td><td>${r.nickname}</td><td>${r.bestPoints}</td><td>${r.bestAccuracy}%</td><td>${r.bestStreakDays || 0}</td></tr>`)
    .join("");

  const html = `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>学习总报告 - ${studentProfile.nickname}</title>
  <style>
    body { font-family: "Microsoft YaHei", Arial, sans-serif; color: #1f2b56; margin: 24px; }
    h1, h2 { margin: 0 0 10px; }
    .muted { color: #5d6f9a; margin-bottom: 16px; }
    .card { border: 1px solid #d6dff9; border-radius: 12px; padding: 14px; margin-bottom: 14px; }
    .grid { display: grid; grid-template-columns: repeat(4, minmax(120px, 1fr)); gap: 10px; }
    .kpi { background: #f6f8ff; border-radius: 10px; padding: 10px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #dbe3fb; padding: 8px; text-align: left; font-size: 14px; }
    th { background: #edf2ff; }
    .chart { width: 100%; border: 1px solid #dbe3fb; border-radius: 12px; margin-top: 8px; }
    .small { font-size: 13px; color: #5d6f9a; }
    @media print { body { margin: 8mm; } .card { break-inside: avoid; } }
  </style>
</head>
<body>
  <h1>2026新人教版PEP六年级英语上册综合知识记忆训练营 - 学习总报告</h1>
  <p class="muted">学生：${studentProfile.nickname} | 导出时间：${nowText()}</p>

  <section class="card">
    <h2>学习概览</h2>
    <div class="grid">
      <div class="kpi">答对：${stats.correct}</div>
      <div class="kpi">答错：${stats.wrong}</div>
      <div class="kpi">总答题：${stats.attempts}</div>
      <div class="kpi">正确率：${accuracy}%</div>
      <div class="kpi">当前积分：${stats.points}</div>
      <div class="kpi">累积积分：${stats.accumulatedPoints || 0}</div>
      <div class="kpi">连续打卡：${calculateCurrentStreakDays()} 天</div>
      <div class="kpi">错题本：${wrongBookItems.length} 条</div>
    </div>
  </section>

  <section class="card">
    <h2>排行榜 Top 3</h2>
    <table>
      <thead><tr><th>名次</th><th>昵称</th><th>最高积分</th><th>最高正确率</th><th>连续打卡天数</th></tr></thead>
      <tbody>${topRows || `<tr><td colspan="5">暂无排行数据</td></tr>`}</tbody>
    </table>
  </section>

  <section class="card">
    <h2>最近挑战记录（前20条）</h2>
    <table>
      <thead><tr><th>时间</th><th>项目</th><th>结果</th><th>积分变化</th></tr></thead>
      <tbody>
        ${(challengeLogs.slice(0, 20).map((i) => `<tr><td>${i.time}</td><td>${i.item}</td><td>${i.result}</td><td>${i.pointDelta}</td></tr>`).join("")) || `<tr><td colspan="4">暂无记录</td></tr>`}
      </tbody>
    </table>
  </section>
</body>
</html>`;

  downloadTextFile(`学习总报告_${studentProfile.nickname}_${todayKey()}.html`, html, "text/html");
  elements.exportFeedback.textContent = "学习总报告已导出（HTML，可直接打印）。";
}

function buildPointLedgerEntries() {
  const entries = [];
  challengeLogs.forEach((log) => {
    if (!log.pointDelta) return;
    entries.push({
      time: log.time,
      flow: log.pointDelta > 0 ? "earn" : "spend",
      category: "练习挑战",
      name: log.item,
      detail: log.result,
      points: log.pointDelta,
    });
  });
  behaviorLogs.forEach((log) => {
    entries.push({
      time: log.time,
      flow: log.points > 0 ? "earn" : "spend",
      category: "行为积分",
      name: log.label,
      detail: log.category === "good" ? "良好行为" : "待改进行为",
      points: log.points,
    });
  });
  redeemLogs.forEach((log) => {
    entries.push({
      time: log.time,
      flow: "spend",
      category: "积分兑换",
      name: log.name,
      detail: "兑换消费",
      points: -Math.abs(log.cost),
    });
  });
  return entries.sort((a, b) => String(b.time).localeCompare(String(a.time)));
}

function exportPointsLedgerHtml() {
  const entries = buildPointLedgerEntries();
  const totalEarned = entries.filter((e) => e.points > 0).reduce((s, e) => s + e.points, 0);
  const totalSpent = entries.filter((e) => e.points < 0).reduce((s, e) => s + Math.abs(e.points), 0);
  const earnRows = entries
    .filter((e) => e.points > 0)
    .map((e) => `<tr><td>${e.time}</td><td>${e.category}</td><td>${e.name}</td><td>${e.detail}</td><td class="earn">+${e.points}</td></tr>`)
    .join("");
  const spendRows = entries
    .filter((e) => e.points < 0)
    .map((e) => `<tr><td>${e.time}</td><td>${e.category}</td><td>${e.name}</td><td>${e.detail}</td><td class="spend">${e.points}</td></tr>`)
    .join("");

  const html = `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>积分台账 - ${studentProfile.nickname}</title>
  <style>
    body { font-family: "Microsoft YaHei", Arial, sans-serif; color: #1f2b56; margin: 24px; }
    h1, h2 { margin: 0 0 10px; }
    .muted { color: #5d6f9a; margin-bottom: 16px; }
    .card { border: 1px solid #d6dff9; border-radius: 12px; padding: 14px; margin-bottom: 14px; }
    .grid { display: grid; grid-template-columns: repeat(4, minmax(120px, 1fr)); gap: 10px; }
    .kpi { background: #f6f8ff; border-radius: 10px; padding: 10px; font-weight: 700; }
    .kpi.highlight { background: linear-gradient(180deg, #f8f0ff 0%, #efe2ff 100%); border: 1px solid #b896ff; }
    table { width: 100%; border-collapse: collapse; margin-top: 8px; }
    th, td { border: 1px solid #dbe3fb; padding: 8px; text-align: left; font-size: 14px; }
    th { background: #edf2ff; }
    .earn { color: #16a34a; font-weight: 800; }
    .spend { color: #dc2626; font-weight: 800; }
    @media print { body { margin: 8mm; } .card { break-inside: avoid; } }
  </style>
</head>
<body>
  <h1>积分获取与消费总报告</h1>
  <p class="muted">学生：${studentProfile.nickname} | 导出时间：${nowText()} | 旭日长空光照人生出品</p>

  <section class="card">
    <h2>积分概览</h2>
    <div class="grid">
      <div class="kpi">当前积分：${stats.points}</div>
      <div class="kpi highlight">累积积分：${stats.accumulatedPoints || 0}</div>
      <div class="kpi earn">累计获得：+${totalEarned}</div>
      <div class="kpi spend">累计消费：-${totalSpent}</div>
    </div>
    <p class="muted">说明：累计获得/消费由挑战记录、行为积分、兑换记录汇总计算。</p>
  </section>

  <section class="card">
    <h2>积分获取明细</h2>
    <table>
      <thead><tr><th>时间</th><th>类型</th><th>项目</th><th>说明</th><th>积分</th></tr></thead>
      <tbody>${earnRows || `<tr><td colspan="5">暂无获取记录</td></tr>`}</tbody>
    </table>
  </section>

  <section class="card">
    <h2>积分消费明细</h2>
    <table>
      <thead><tr><th>时间</th><th>类型</th><th>项目</th><th>说明</th><th>积分</th></tr></thead>
      <tbody>${spendRows || `<tr><td colspan="5">暂无消费记录</td></tr>`}</tbody>
    </table>
  </section>
</body>
</html>`;

  downloadTextFile(`积分台账_${studentProfile.nickname}_${todayKey()}.html`, html, "text/html");
  elements.exportFeedback.textContent = "积分台账已导出（HTML，含获取与消费明细）。";
}

function updateDashboard() {
  elements.correctCount.textContent = String(stats.correct);
  elements.wrongCount.textContent = String(stats.wrong);
  elements.attemptCount.textContent = String(stats.attempts);
  const accuracy = stats.attempts === 0 ? 0 : Math.round((stats.correct / stats.attempts) * 100);
  elements.accuracy.textContent = `${accuracy}%`;
  elements.pointCount.textContent = String(stats.points);
  elements.cumulativePointCount.textContent = String(stats.accumulatedPoints || 0);
  elements.wrongBookCount.textContent = String(wrongBookItems.length);
  elements.nicknameDisplay.textContent = `学生昵称：${studentProfile.nickname}`;
  elements.lastPracticeTime.textContent = `最近练习时间：${stats.lastPracticeAt || "暂无"}`;
  updateLeaderboard();
  renderLeaderboard();
  renderCharts();
}

function setActiveTab(tabName) {
  elements.tabs.forEach((tab) => {
    tab.classList.toggle("active", tab.dataset.tab === tabName);
  });
  elements.panels.forEach((panel) => {
    panel.classList.toggle("active", panel.id === tabName);
  });
}

function renderCard() {
  if (filteredCards.length === 0) {
    elements.cardCategory.textContent = "暂无数据";
    elements.cardFront.textContent = "请切换单元";
    elements.cardPhonetic.textContent = "";
    elements.cardZh.textContent = "当前筛选没有单词。";
    elements.cardExample.textContent = "";
    elements.cardExampleZh.textContent = "";
    elements.cardImage.classList.add("hidden");
    return;
  }
  const card = filteredCards[cardIndex];
  elements.cardCategory.textContent = `${unitMeta[card.unit]} · ${card.category}`;
  elements.cardFront.textContent = card.front;
  elements.cardPhonetic.textContent = card.ipa || "";
  elements.cardZh.textContent = card.zh || "";
  elements.cardExample.textContent = card.example ? `例句: ${card.example}` : "";
  elements.cardExampleZh.textContent = card.exampleZh ? `翻译: ${card.exampleZh}` : "";
  const imageSrc = card.image || unitLocalImage[card.unit];
  if (imageSrc) {
    const preview = new Image();
    preview.onload = () => {
      elements.cardImage.src = imageSrc;
      elements.cardImage.classList.remove("hidden");
    };
    preview.onerror = () => {
      elements.cardImage.classList.add("hidden");
      elements.cardImage.removeAttribute("src");
    };
    preview.src = imageSrc;
  } else {
    elements.cardImage.classList.add("hidden");
    elements.cardImage.removeAttribute("src");
  }
  cardFlipped = false;
  elements.cardBack.classList.add("hidden");
}

function adjustPoints(delta) {
  stats.points += delta;
  if (stats.points < 0) stats.points = 0;
  if (delta > 0) stats.accumulatedPoints = (stats.accumulatedPoints || 0) + delta;
  if (stats.points > stats.highestPoints) stats.highestPoints = stats.points;
  checkAndGrantBadges();
}

function markPractice() {
  stats.lastPracticeAt = nowText();
}

function addChallengeLog(item, result, pointDelta) {
  challengeLogs.unshift({
    time: nowText(),
    item,
    result,
    pointDelta,
  });
  challengeLogs = challengeLogs.slice(0, 200);
  saveChallengeLogs();
}

function renderChallengeLogs() {
  if (challengeLogs.length === 0) {
    elements.challengeList.textContent = "暂无挑战记录";
    return;
  }
  elements.challengeList.innerHTML = challengeLogs
    .slice(0, 40)
    .map((log) => `<div>${log.time} | ${log.item} | ${log.result} | 积分变化 ${log.pointDelta > 0 ? "+" : ""}${log.pointDelta}</div>`)
    .join("");
}

function renderRedeemLogs() {
  if (redeemLogs.length === 0) {
    elements.redeemList.textContent = "暂无兑换记录";
    return;
  }
  elements.redeemList.innerHTML = redeemLogs
    .slice(0, 40)
    .map((log) => `<div>${log.time} | 兑换：${log.name} | 消耗 ${log.cost} 积分</div>`)
    .join("");
}

function redeemPointsRecord() {
  const name = elements.redeemName.value.trim();
  const cost = Number(elements.redeemCost.value || 0);
  if (!name || cost <= 0) {
    addChallengeLog("积分兑换", "失败（信息不完整）", 0);
    renderChallengeLogs();
    return;
  }
  if (stats.points < cost) {
    addChallengeLog("积分兑换", "失败（积分不足）", 0);
    renderChallengeLogs();
    return;
  }
  stats.points -= cost;
  stats.lastSpendDate = todayKey();
  markPractice();
  redeemLogs.unshift({ time: nowText(), name, cost });
  redeemLogs = redeemLogs.slice(0, 200);
  saveRedeemLogs();
  saveStats();
  addChallengeLog("积分兑换", "成功", -cost);
  elements.redeemName.value = "";
  elements.redeemCost.value = "";
  updateDashboard();
  renderRedeemLogs();
  renderChallengeLogs();
  renderCharts();
}

function saveNickname() {
  const nickname = elements.nicknameInput.value.trim();
  if (!nickname) return;
  studentProfile.nickname = nickname;
  saveStudentProfile();
  updateDashboard();
}

function resetAllData() {
  const ok = window.confirm("此操作会删除所有学习数据（昵称、积分、排行榜、挑战记录、错题本、日志等），并恢复到初始状态，请确认是否继续？");
  if (!ok) return;
  stats = { correct: 0, wrong: 0, attempts: 0, points: 0, highestPoints: 0, accumulatedPoints: 0, lastPracticeAt: "", lastCompoundDate: "", lastSpendDate: "" };
  wrongQuizIds = [];
  wrongBookItems = [];
  wrongBookMode = false;
  challengeLogs = [];
  redeemLogs = [];
  behaviorLogs = [];
  badges = [];
  journalEntries = [];
  leaderboard = [];
  studentProfile = { nickname: "同学" };
  elements.nicknameInput.value = "";
  if (elements.leaderboardSort) elements.leaderboardSort.value = "points";
  if (elements.exportFeedback) elements.exportFeedback.textContent = "";
  saveStats();
  saveWrongQuizIds();
  saveWrongBookItems();
  saveChallengeLogs();
  saveRedeemLogs();
  saveBehaviorLogs();
  saveBadges();
  saveJournalEntries();
  saveLeaderboard();
  saveStudentProfile();
  refreshQuizWithFilters();
  updateDashboard();
  renderChallengeLogs();
  renderRedeemLogs();
  renderWrongBookItems();
  renderBadgeList();
  renderJournal();
  renderCharts();
  updateWrongBookStatus();
}

function markManualAnswerCorrect() {
  stats.attempts += 1;
  stats.correct += 1;
  adjustPoints(POINT_REWARD);
  markPractice();
  addChallengeLog("手动记录", "回答正确", POINT_REWARD);
  saveStats();
  updateDashboard();
  renderChallengeLogs();
  showSuccessFx();
}

function markManualAnswerWrong() {
  stats.attempts += 1;
  stats.wrong += 1;
  markPractice();
  addChallengeLog("手动记录", "回答错误", 0);
  saveStats();
  updateDashboard();
  renderChallengeLogs();
}

function clearFxLayerLater() {
  window.setTimeout(() => {
    elements.fxLayer.innerHTML = "";
  }, 1400);
}

function showSuccessFx() {
  const colors = ["#ff6b6b", "#ffd93d", "#6bcb77", "#4d96ff", "#ff8fab", "#72ddf7"];
  for (let i = 0; i < 120; i += 1) {
    const piece = document.createElement("span");
    piece.className = "fx-confetti";
    piece.style.left = `${Math.random() * 100}%`;
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDelay = `${Math.random() * 220}ms`;
    elements.fxLayer.appendChild(piece);
  }
  clearFxLayerLater();
}

function showFailFx() {
  const emojis = ["😞", "😢", "😭", "🙁", "😔"];
  for (let i = 0; i < 28; i += 1) {
    const item = document.createElement("span");
    item.className = "fx-sad";
    item.textContent = emojis[Math.floor(Math.random() * emojis.length)];
    item.style.left = `${Math.random() * 95}%`;
    item.style.animationDelay = `${Math.random() * 160}ms`;
    elements.fxLayer.appendChild(item);
  }
  clearFxLayerLater();
}

function toggleCardFlip() {
  cardFlipped = !cardFlipped;
  elements.cardBack.classList.toggle("hidden", !cardFlipped);
}

function nextCard(step) {
  const total = filteredCards.length;
  if (total === 0) return;
  cardIndex = (cardIndex + step + total) % total;
  renderCard();
}

function updateUnitFilter() {
  const unitValue = elements.unitFilter.value;
  filteredCards = unitValue === "all" ? [...vocabularyCards] : vocabularyCards.filter((item) => String(item.unit) === unitValue);
  cardIndex = 0;
  renderCard();
}

function updateWrongBookStatus() {
  const totalWrong = wrongBookItems.length;
  const modeText = wrongBookMode ? "当前模式：错题本复习" : "当前模式：普通刷题";
  elements.wrongBookStatus.textContent = `${modeText} | 错题数量：${totalWrong}`;
  elements.startWrongBook.textContent = wrongBookMode ? "退出错题本" : "错题本复习";
  elements.wrongBookCount.textContent = String(totalWrong);
}

function randomFrom(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function shuffle(array) {
  const result = [...array];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function renderQuiz() {
  if (filteredQuizzes.length === 0) {
    currentQuiz = null;
    elements.quizBadge.textContent = wrongBookMode ? "错题本暂无可练习题目" : "当前筛选暂无题目";
    elements.quizPrompt.textContent = "请调整 Unit / Part 筛选，或先做一些题生成错题本。";
    elements.quizFeedback.textContent = "";
    elements.quizAnalysis.textContent = "";
    elements.quizOptions.innerHTML = "";
    return;
  }

  currentQuiz = randomFrom(filteredQuizzes);
  const modeTag = wrongBookMode ? "错题本" : "闯关";
  elements.quizBadge.textContent = `${modeTag} | ${currentQuiz.badge}`;
  elements.quizPrompt.textContent = currentQuiz.prompt;
  elements.quizFeedback.textContent = "";
  elements.quizAnalysis.textContent = "请选择一个选项，我会给你详细解析。";
  elements.quizAnalysis.style.color = "#55627a";
  elements.quizOptions.innerHTML = "";

  shuffle(currentQuiz.options).forEach((option) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "secondary-btn option-btn";
    button.textContent = option;
    button.addEventListener("click", () => handleQuizAnswer(option));
    elements.quizOptions.appendChild(button);
  });
}

function handleQuizAnswer(option) {
  if (!currentQuiz) return;
  stats.attempts += 1;
  if (option === currentQuiz.answer) {
    stats.correct += 1;
    adjustPoints(POINT_REWARD);
    markPractice();
    addChallengeLog("选择题", "正确", POINT_REWARD);
    elements.quizFeedback.textContent = `✅ 回答正确，闯关成功！+${POINT_REWARD} 积分`;
    elements.quizFeedback.style.color = "#0f9d58";
    elements.quizAnalysis.textContent = `解析：${currentQuiz.explainCorrect}`;
    elements.quizAnalysis.style.color = "#0f9d58";
    showSuccessFx();
  } else {
    stats.wrong += 1;
    adjustPoints(-POINT_PENALTY);
    markPractice();
    addChallengeLog("选择题", "错误", -POINT_PENALTY);
    elements.quizFeedback.textContent = `❌ 回答错误，正确答案是：${currentQuiz.answer}，-${POINT_PENALTY} 积分`;
    elements.quizFeedback.style.color = "#b00020";
    const reason = currentQuiz.optionReasons[option] || "这个选项不符合本题语法规则。";
    elements.quizAnalysis.textContent = `错因分析：${reason}；正确思路：${currentQuiz.explainCorrect}`;
    elements.quizAnalysis.style.color = "#b00020";

    if (!wrongQuizIds.includes(currentQuiz.id)) {
      wrongQuizIds.push(currentQuiz.id);
      saveWrongQuizIds();
    }
    addWrongBookItem("选择题", currentQuiz.prompt, currentQuiz.answer);
    showFailFx();
  }
  saveStats();
  updateDashboard();
  updateWrongBookStatus();
  renderChallengeLogs();
}

function renderGrammar() {
  const point = grammarPoints[grammarIndex];
  elements.grammarTitle.textContent = point.title;
  elements.grammarRule.textContent = point.rule;
  const rows = point.examples.map((example) => `<p>✅ ${example}</p>`).join("");
  elements.grammarExample.innerHTML = rows;
}

function nextGrammarPoint() {
  grammarIndex = (grammarIndex + 1) % grammarPoints.length;
  renderGrammar();
}

function renderPhrase() {
  const phrase = commonPhrases[phraseIndex];
  elements.phraseScene.textContent = `场景: ${phrase.scene}`;
  elements.phraseMasked.textContent = phrase.en.replace(phrase.key, "______");
  elements.phraseEn.textContent = phrase.en;
  elements.phraseEn.classList.add("hidden");
  elements.phraseMasked.classList.remove("hidden");
  phraseFlipped = false;
  elements.phraseHint.textContent = "点击闪卡显示答案";
  elements.phraseZh.textContent = `中文: ${phrase.zh}`;
}

function nextPhraseItem() {
  phraseIndex = (phraseIndex + 1) % commonPhrases.length;
  renderPhrase();
}

function togglePhraseCard() {
  phraseFlipped = !phraseFlipped;
  elements.phraseMasked.classList.toggle("hidden", phraseFlipped);
  elements.phraseEn.classList.toggle("hidden", !phraseFlipped);
  elements.phraseHint.textContent = phraseFlipped ? "再次点击可隐藏关键词" : "点击闪卡显示答案";
}

function updateWritingFilter() {
  const selectedUnit = Number(elements.writingUnitFilter.value);
  filteredWritingSamples = writingSamples.filter((item) => item.unit === selectedUnit);
  writingIndex = 0;
  renderWritingSample();
}

function renderWritingSample() {
  if (filteredWritingSamples.length === 0) {
    elements.writingTitle.textContent = "暂无作文数据";
    elements.writingEn.textContent = "";
    elements.writingZh.textContent = "";
    elements.writingFillPrompt.textContent = "";
    elements.writingFillFeedback.textContent = "";
    return;
  }
  const sample = filteredWritingSamples[writingIndex];
  elements.writingTitle.textContent = sample.title;
  elements.writingEn.textContent = sample.en;
  elements.writingZh.textContent = `参考译文: ${sample.zh}`;
  elements.writingFillPrompt.textContent = sample.fillPrompt;
  elements.writingFillInput.value = "";
  elements.writingFillFeedback.textContent = "";
}

function nextWritingSample() {
  if (filteredWritingSamples.length === 0) return;
  writingIndex = (writingIndex + 1) % filteredWritingSamples.length;
  renderWritingSample();
}

function checkWritingFillAnswer() {
  const sample = filteredWritingSamples[writingIndex];
  if (!sample) return;
  const answer = elements.writingFillInput.value.trim().toLowerCase();
  if (!answer) {
    elements.writingFillFeedback.textContent = "请先填写答案。";
    elements.writingFillFeedback.style.color = "#b00020";
    return;
  }
  if (answer === sample.fillAnswer.toLowerCase()) {
    stats.attempts += 1;
    stats.correct += 1;
    adjustPoints(POINT_REWARD);
    markPractice();
    addChallengeLog("作文填空", "正确", POINT_REWARD);
    elements.writingFillFeedback.textContent = `填空正确！+${POINT_REWARD} 积分`;
    elements.writingFillFeedback.style.color = "#0f9d58";
    showSuccessFx();
  } else {
    stats.attempts += 1;
    stats.wrong += 1;
    adjustPoints(-POINT_PENALTY);
    markPractice();
    addChallengeLog("作文填空", "错误", -POINT_PENALTY);
    addWrongBookItem("作文填空", sample.fillPrompt, sample.fillAnswer);
    elements.writingFillFeedback.textContent = `答案不对，正确答案：${sample.fillAnswer}，-${POINT_PENALTY} 积分`;
    elements.writingFillFeedback.style.color = "#b00020";
    showFailFx();
  }
  saveStats();
  updateDashboard();
  renderChallengeLogs();
}

function renderSvoExercise() {
  const item = svoExercises[svoIndex];
  elements.svoSentenceHint.textContent = `句子：${item.sentenceHint}`;
  svoUserAnswer = { subject: "", verb: "", object: "" };
  activeSvoSlot = "subject";
  elements.slotSubject.textContent = "主语 (S)";
  elements.slotVerb.textContent = "谓语 (V)";
  elements.slotObject.textContent = "宾语/补语 (O)";
  elements.svoFeedback.textContent = "";

  const tokens = shuffle([item.subject, item.verb, item.object]);
  elements.svoTokens.innerHTML = "";
  tokens.forEach((token) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "svo-token";
    btn.textContent = token;
    btn.addEventListener("click", () => assignSvoToken(token));
    elements.svoTokens.appendChild(btn);
  });
  highlightActiveSlot();
}

function highlightActiveSlot() {
  const mapping = {
    subject: elements.slotSubject,
    verb: elements.slotVerb,
    object: elements.slotObject,
  };
  Object.entries(mapping).forEach(([key, el]) => {
    el.classList.toggle("active-slot", key === activeSvoSlot);
  });
}

function setActiveSvoSlot(slot) {
  activeSvoSlot = slot;
  highlightActiveSlot();
}

function assignSvoToken(token) {
  svoUserAnswer[activeSvoSlot] = token;
  if (activeSvoSlot === "subject") elements.slotSubject.textContent = `主语 (S): ${token}`;
  if (activeSvoSlot === "verb") elements.slotVerb.textContent = `谓语 (V): ${token}`;
  if (activeSvoSlot === "object") elements.slotObject.textContent = `宾语/补语 (O): ${token}`;
}

function checkSvoExercise() {
  const item = svoExercises[svoIndex];
  const done = svoUserAnswer.subject && svoUserAnswer.verb && svoUserAnswer.object;
  if (!done) {
    elements.svoFeedback.textContent = "请先把主语、谓语、宾语都填上。";
    elements.svoFeedback.style.color = "#b00020";
    return;
  }
  stats.attempts += 1;
  const ok = svoUserAnswer.subject === item.subject && svoUserAnswer.verb === item.verb && svoUserAnswer.object === item.object;
  if (ok) {
    stats.correct += 1;
    adjustPoints(POINT_REWARD);
    markPractice();
    addChallengeLog("语法连连看", "正确", POINT_REWARD);
    elements.svoFeedback.textContent = `主谓宾匹配正确！+${POINT_REWARD} 积分`;
    elements.svoFeedback.style.color = "#0f9d58";
    showSuccessFx();
  } else {
    stats.wrong += 1;
    adjustPoints(-POINT_PENALTY);
    markPractice();
    addChallengeLog("语法连连看", "错误", -POINT_PENALTY);
    addWrongBookItem("语法连连看", item.sentenceHint, `S=${item.subject}, V=${item.verb}, O=${item.object}`);
    elements.svoFeedback.textContent = `匹配有误，标准答案：S=${item.subject}，V=${item.verb}，O=${item.object}，-${POINT_PENALTY} 积分`;
    elements.svoFeedback.style.color = "#b00020";
    showFailFx();
  }
  saveStats();
  updateDashboard();
  renderChallengeLogs();
}

function nextSvoExercise() {
  svoIndex = (svoIndex + 1) % svoExercises.length;
  renderSvoExercise();
}

function renderAppendixPanel() {
  const lines = [];
  let totalVocab = 0;
  let totalPhrase = 0;
  let totalSentence = 0;
  appendixUnits.forEach((unit) => {
    const vocabA = unit.partAVocab.length;
    const vocabB = unit.partBVocab.length;
    const phraseA = unit.partAPhrases.length;
    const phraseB = unit.partBPhrases.length;
    const sentA = unit.partASentences.length;
    const sentB = unit.partBSentences.length;
    totalVocab += vocabA + vocabB;
    totalPhrase += phraseA + phraseB;
    totalSentence += sentA + sentB;
    const status = vocabA > 0 && vocabB > 0 && phraseA > 0 && phraseB > 0 && sentA > 0 && sentB > 0 ? "完整" : "缺失";
    lines.push(
      `<div class="appendix-row ${status === "完整" ? "ok-row" : "warn-row"}">` +
      `<span>Unit ${unit.num}</span><span>词汇 ${vocabA + vocabB}</span><span>短语 ${phraseA + phraseB}</span><span>句型 ${sentA + sentB}</span><span>${status}</span></div>`,
    );
  });
  elements.appendixSummary.textContent = `全量覆盖统计：词汇 ${totalVocab} 条，短语 ${totalPhrase} 条，句型 ${totalSentence} 条，动词三态 ${verbTriples.length} 组。`;
  elements.appendixTable.innerHTML = `<div class="appendix-head"><span>单元</span><span>词汇</span><span>短语</span><span>句型</span><span>状态</span></div>${lines.join("")}`;
}

function applyQuizFilters() {
  const selectedUnit = elements.quizUnitFilter.value;
  const selectedPart = elements.quizPartFilter.value;

  const unitFiltered = selectedUnit === "all" ? quizzes : quizzes.filter((item) => String(item.unit) === selectedUnit);
  const partFiltered = selectedPart === "all" ? unitFiltered : unitFiltered.filter((item) => item.part === selectedPart);

  if (wrongBookMode) {
    filteredQuizzes = partFiltered.filter((item) => wrongQuizIds.includes(item.id));
  } else {
    filteredQuizzes = partFiltered;
  }
}

function refreshQuizWithFilters() {
  applyQuizFilters();
  updateWrongBookStatus();
  renderQuiz();
}

function toggleWrongBookMode() {
  wrongBookMode = !wrongBookMode;
  refreshQuizWithFilters();
}

function clearWrongBook() {
  wrongQuizIds = [];
  wrongBookItems = [];
  saveWrongQuizIds();
  saveWrongBookItems();
  if (wrongBookMode) {
    wrongBookMode = false;
  }
  refreshQuizWithFilters();
  updateDashboard();
  renderWrongBookItems();
}

function renderVerb() {
  const verb = verbTriples[verbIndex];
  elements.verbBase.textContent = `动词学习 (${unitMeta[verb.unit]}): ${verb.base}`;
  elements.verbInfinitive.textContent = verb.base;
  elements.verbPast.textContent = verb.past;
  elements.verbParticiple.textContent = verb.participle;
  elements.verbUsage.textContent = `用法: ${verb.usage}`;
  elements.verbSentence.textContent = `例句: ${verb.sentence}`;
  elements.verbFillPrompt.textContent = verb.fillPrompt;
  elements.verbFillInput.value = "";
  elements.verbFeedback.textContent = "";
}

function nextVerbItem() {
  verbIndex = (verbIndex + 1) % verbTriples.length;
  renderVerb();
}

function checkVerbAnswer() {
  const input = elements.verbFillInput.value.trim().toLowerCase();
  if (!input) {
    elements.verbFeedback.textContent = "请先填写答案。";
    elements.verbFeedback.style.color = "#b00020";
    return;
  }

  const current = verbTriples[verbIndex];
  const acceptedAnswers = current.fillAnswer
    .toLowerCase()
    .split("/")
    .map((item) => item.trim())
    .filter(Boolean);
  stats.attempts += 1;
  if (acceptedAnswers.includes(input)) {
    stats.correct += 1;
    adjustPoints(POINT_REWARD);
    markPractice();
    addChallengeLog("动词专项", "正确", POINT_REWARD);
    elements.verbFeedback.textContent = `回答正确！+${POINT_REWARD} 积分`;
    elements.verbFeedback.style.color = "#0f9d58";
    showSuccessFx();
  } else {
    stats.wrong += 1;
    adjustPoints(-POINT_PENALTY);
    markPractice();
    addChallengeLog("动词专项", "错误", -POINT_PENALTY);
    addWrongBookItem("动词专项", current.fillPrompt, current.fillAnswer);
    elements.verbFeedback.textContent = `答案不对，正确答案是: ${current.fillAnswer}，-${POINT_PENALTY} 积分`;
    elements.verbFeedback.style.color = "#b00020";
    showFailFx();
  }
  saveStats();
  updateDashboard();
  renderChallengeLogs();
}

function extractKeywords(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length >= 5)
    .slice(0, 8);
}

function scoreWritingDraft() {
  const sample = filteredWritingSamples[writingIndex];
  const draft = elements.writingStudentInput.value.trim();
  if (!draft) {
    elements.writingScore.textContent = "请先写作文再评分。";
    elements.writingAdvice.textContent = "";
    return;
  }
  const words = draft.split(/\s+/).filter(Boolean);
  const sentenceCount = draft.split(/[.!?]+/).map((s) => s.trim()).filter(Boolean).length;
  const completeness = Math.min(40, sentenceCount >= 3 ? 40 : sentenceCount * 12);

  const targetKeywords = extractKeywords(sample.en);
  const lower = draft.toLowerCase();
  const hitCount = targetKeywords.filter((k) => lower.includes(k)).length;
  const keywordScore = targetKeywords.length === 0 ? 0 : Math.round((hitCount / targetKeywords.length) * 35);

  const tenseSignals = ["yesterday", "last", "ago", "did", "went", "saw", "ate", "took", "sent", "won", "was", "were"];
  const tenseHits = tenseSignals.filter((s) => lower.includes(s)).length;
  const tenseScore = Math.min(25, tenseHits * 4);

  const total = Math.min(100, completeness + keywordScore + tenseScore);
  const tips = [];
  if (sentenceCount < 3) tips.push("句型完整度不足：建议至少写 3 句，并加句号。");
  if (keywordScore < 20) tips.push("关键词覆盖偏低：多使用本单元核心词汇与短语。");
  if (tenseScore < 12) tips.push("时态表达偏弱：尝试加入过去时或一般现在时的标准句。");
  if (words.length < 40) tips.push("篇幅偏短：建议写到 40~80 词更完整。");
  if (tips.length === 0) tips.push("表达很好！可以尝试使用更复杂的连接词提升层次。");

  markPractice();
  saveStats();
  updateDashboard();
  addChallengeLog("作文评分器", "完成评分", 0);
  renderChallengeLogs();

  elements.writingScore.textContent = `作文评分：${total}/100（句型 ${completeness}/40，关键词 ${keywordScore}/35，时态 ${tenseScore}/25）`;
  elements.writingScore.style.color = total >= 85 ? "#0f9d58" : total >= 60 ? "#b06d00" : "#b00020";
  elements.writingAdvice.textContent = `改进建议：${tips.join("；")}`;
}

function buildFillBlankSet() {
  const selectedUnit = elements.fillUnitFilter.value;
  const vocabPool = selectedUnit === "all" ? vocabularyCards : vocabularyCards.filter((item) => String(item.unit) === selectedUnit);
  const verbPool = selectedUnit === "all" ? verbTriples : verbTriples.filter((item) => String(item.unit) === selectedUnit);
  const vocabQuestions = shuffle(vocabPool).slice(0, 3).map((item, idx) => ({
    id: `v-${idx}`,
    type: "vocab",
    prompt: item.example ? item.example.replace(new RegExp(item.front, "i"), "____") : `请填写单词：____ (${item.zh})`,
    clue: item.zh,
    answer: item.front.toLowerCase(),
  }));
  const verbQuestions = shuffle(verbPool).slice(0, 2).map((item, idx) => ({
    id: `vb-${idx}`,
    type: "verb",
    prompt: item.fillPrompt,
    clue: `${item.fillClue || ""}；动词原形：${item.base}`,
    answer: item.fillAnswer.toLowerCase(),
  }));
  currentFillQuestions = shuffle([...vocabQuestions, ...verbQuestions]).slice(0, 5);
  renderFillBlankSet();
}

function renderFillBlankSet() {
  elements.fillQuestions.innerHTML = currentFillQuestions
    .map((q, idx) => `<div class="fill-q"><p><strong>${idx + 1}.</strong> ${q.prompt}</p><p class="model">提示：${q.clue}</p><input id="fillInput-${q.id}" type="text" placeholder="请填写英文单词（可用中文提示）" /></div>`)
    .join("");
  elements.fillSetFeedback.textContent = "";
}

function submitFillBlankSet() {
  if (currentFillQuestions.length === 0) return;
  let correct = 0;
  let invalidCount = 0;
  currentFillQuestions.forEach((q) => {
    const inputEl = document.getElementById(`fillInput-${q.id}`);
    const value = (inputEl?.value || "").trim().toLowerCase();
    if (!/^[a-z][a-z\s'-]*$/.test(value)) {
      invalidCount += 1;
      addWrongBookItem("综合填空", q.prompt, q.answer);
      return;
    }
    const validAnswers = String(q.answer)
      .split("/")
      .map((i) => i.trim())
      .filter(Boolean);
    if (validAnswers.includes(value)) correct += 1;
    else addWrongBookItem("综合填空", q.prompt, q.answer);
  });
  const wrong = currentFillQuestions.length - correct;
  const delta = correct * 20 - wrong * 5;
  stats.attempts += currentFillQuestions.length;
  stats.correct += correct;
  stats.wrong += wrong;
  adjustPoints(delta);
  markPractice();
  addChallengeLog("综合填空5题", `正确${correct}题`, delta);
  saveStats();
  updateDashboard();
  renderChallengeLogs();
  if (correct >= 4) showSuccessFx(); else showFailFx();
  elements.fillSetFeedback.textContent = `本组结果：答对 ${correct}/5，答错 ${wrong}/5，积分变化 ${delta >= 0 ? "+" : ""}${delta}${invalidCount > 0 ? `（其中 ${invalidCount} 题未按英文单词规范填写）` : ""}`;
  elements.fillSetFeedback.style.color = correct >= 4 ? "#0f9d58" : "#b00020";
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function renderJournal() {
  const key = todayKey();
  elements.journalToday.textContent = `今天日期：${key}`;
  if (journalEntries.length === 0) {
    elements.journalList.textContent = "暂无日志";
    return;
  }
  elements.journalList.innerHTML = journalEntries
    .slice()
    .reverse()
    .map((entry) => `<div><strong>${entry.date}</strong>：${entry.text}</div>`)
    .join("");
}

function saveJournalToday() {
  const text = elements.journalInput.value.trim();
  const wordCount = text ? text.split(/\s+/).filter(Boolean).length : 0;
  if (!text) {
    elements.journalFeedback.textContent = "请输入日志内容。";
    elements.journalFeedback.style.color = "#b00020";
    return;
  }
  if (wordCount > 100) {
    elements.journalFeedback.textContent = `超过 100 词（当前 ${wordCount} 词），请精简后再保存。`;
    elements.journalFeedback.style.color = "#b00020";
    return;
  }
  const key = todayKey();
  const existing = journalEntries.find((item) => item.date === key);
  if (existing) {
    existing.text = text;
  } else {
    journalEntries.push({ date: key, text });
  }
  saveJournalEntries();
  elements.journalFeedback.textContent = "今日日志已保存。";
  elements.journalFeedback.style.color = "#0f9d58";
  addChallengeLog("学习日志", "保存成功", 0);
  renderChallengeLogs();
  renderJournal();
}

function bindEvents() {
  elements.saveNickname.addEventListener("click", saveNickname);
  elements.resetAllStats.addEventListener("click", resetAllData);
  elements.redeemPoints.addEventListener("click", redeemPointsRecord);
  elements.exportReport.addEventListener("click", exportLearningReport);
  elements.exportReportHtml.addEventListener("click", exportPrintableHtmlReport);
  elements.exportPointsHtml.addEventListener("click", exportPointsLedgerHtml);
  elements.markAnswerCorrect.addEventListener("click", markManualAnswerCorrect);
  elements.markAnswerWrong.addEventListener("click", markManualAnswerWrong);
  elements.applyBehaviorAction.addEventListener("click", applyBehaviorAction);
  elements.leaderboardSort.addEventListener("change", renderLeaderboard);

  elements.tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      setActiveTab(tab.dataset.tab);
    });
  });

  elements.flashcard.addEventListener("click", toggleCardFlip);
  elements.flashcard.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      toggleCardFlip();
    }
  });

  elements.prevCard.addEventListener("click", () => nextCard(-1));
  elements.nextCard.addEventListener("click", () => nextCard(1));
  elements.unitFilter.addEventListener("change", updateUnitFilter);
  elements.nextGrammar.addEventListener("click", nextGrammarPoint);
  elements.slotSubject.addEventListener("click", () => setActiveSvoSlot("subject"));
  elements.slotVerb.addEventListener("click", () => setActiveSvoSlot("verb"));
  elements.slotObject.addEventListener("click", () => setActiveSvoSlot("object"));
  elements.checkSvo.addEventListener("click", checkSvoExercise);
  elements.nextSvo.addEventListener("click", nextSvoExercise);
  elements.phraseCard.addEventListener("click", togglePhraseCard);
  elements.phraseCard.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      togglePhraseCard();
    }
  });
  elements.nextPhrase.addEventListener("click", nextPhraseItem);
  elements.writingUnitFilter.addEventListener("change", updateWritingFilter);
  elements.checkWritingFill.addEventListener("click", checkWritingFillAnswer);
  elements.nextWriting.addEventListener("click", nextWritingSample);
  elements.quizUnitFilter.addEventListener("change", refreshQuizWithFilters);
  elements.quizPartFilter.addEventListener("change", refreshQuizWithFilters);
  elements.startWrongBook.addEventListener("click", toggleWrongBookMode);
  elements.clearWrongBook.addEventListener("click", clearWrongBook);
  elements.nextQuestion.addEventListener("click", renderQuiz);
  elements.fillUnitFilter.addEventListener("change", buildFillBlankSet);
  elements.submitFillSet.addEventListener("click", submitFillBlankSet);
  elements.nextFillSet.addEventListener("click", buildFillBlankSet);
  elements.checkVerb.addEventListener("click", checkVerbAnswer);
  elements.nextVerb.addEventListener("click", nextVerbItem);
  elements.refreshAppendix.addEventListener("click", renderAppendixPanel);
  elements.scoreWriting.addEventListener("click", scoreWritingDraft);
  elements.saveJournal.addEventListener("click", saveJournalToday);
}

function init() {
  applyCompoundInterestIfNeeded();
  populateBehaviorActions();
  updateDashboard();
  renderLeaderboard();
  renderWrongBookItems();
  renderBadgeList();
  renderCharts();
  renderChallengeLogs();
  renderRedeemLogs();
  updateUnitFilter();
  updateWritingFilter();
  buildFillBlankSet();
  applyQuizFilters();
  updateWrongBookStatus();
  renderGrammar();
  renderSvoExercise();
  renderPhrase();
  renderAppendixPanel();
  renderJournal();
  renderQuiz();
  renderVerb();
  bindEvents();
}

init();
