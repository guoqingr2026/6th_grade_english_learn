@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set PORT=8080

where python >nul 2>&1
if %errorlevel%==0 (
  echo [启动] 正在启动本地服务 http://localhost:%PORT%
  start "" "http://localhost:%PORT%"
  python -m http.server %PORT%
  goto :eof
)

where py >nul 2>&1
if %errorlevel%==0 (
  echo [启动] 正在启动本地服务 http://localhost:%PORT%
  start "" "http://localhost:%PORT%"
  py -m http.server %PORT%
  goto :eof
)

echo [错误] 未找到 Python，请先安装 Python 3 后再运行。
echo 也可手动双击 index.html 打开（部分功能可能受限）。
pause
